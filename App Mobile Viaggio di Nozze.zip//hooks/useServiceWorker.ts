import { useState, useEffect } from 'react';

interface ServiceWorkerHook {
  isSupported: boolean;
  isRegistered: boolean;
  updateAvailable: boolean;
  isInstallable: boolean;
  isOnline: boolean;
  isAppInstalled: boolean;
  registration: ServiceWorkerRegistration | null;
  registrationError: string | null;
  swVersion: string | null;
  installApp: () => Promise<void>;
  applyUpdate: () => Promise<void>;
  clearCache: () => Promise<void>;
  getSwVersion: () => Promise<string>;
}

export function useServiceWorker(): ServiceWorkerHook {
  const [isSupported, setIsSupported] = useState(false);
  const [isRegistered, setIsRegistered] = useState(false);
  const [updateAvailable, setUpdateAvailable] = useState(false);
  const [isInstallable, setIsInstallable] = useState(false);
  const [isOnline, setIsOnline] = useState(navigator.onLine);
  const [isAppInstalled, setIsAppInstalled] = useState(false);
  const [registration, setRegistration] = useState<ServiceWorkerRegistration | null>(null);
  const [registrationError, setRegistrationError] = useState<string | null>(null);
  const [swVersion, setSwVersion] = useState<string | null>(null);
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);

  useEffect(() => {
    // Check environment early
    const isFigmaPreview = window.location.hostname.includes('figma.site');
    const isLocalhost = window.location.hostname === 'localhost' || window.location.hostname === '127.0.0.1';
    const isHTTPS = window.location.protocol === 'https:';
    
    // Check if service workers are supported
    const supported = 'serviceWorker' in navigator;
    setIsSupported(supported);

    // Skip service worker registration in Figma preview environment
    if (isFigmaPreview) {
      console.log('🔍 Figma preview environment detected - skipping Service Worker registration');
      setRegistrationError('Service Worker disabled in preview environment (this is normal)');
      setIsRegistered(false);
      setRegistration(null);
    } else if (!supported) {
      console.log('❌ Service Workers not supported');
      setRegistrationError('Service Workers not supported by this browser');
    } else if (!isHTTPS && !isLocalhost) {
      console.log('🔒 Service Workers require HTTPS or localhost');
      setRegistrationError('Service Workers require HTTPS or localhost');
    } else {
      // Only attempt registration if we're in a proper environment
      const registerServiceWorker = async () => {
        try {
          console.log('🚀 Attempting to register service worker...');
          const reg = await navigator.serviceWorker.register('/sw.js', {
            scope: '/',
            updateViaCache: 'none' // Always check for updates
          });
          
          console.log('✅ Service Worker registered successfully:', reg);
          setRegistration(reg);
          setIsRegistered(true);
          setRegistrationError(null);

          // Get initial version
          getSwVersionFromWorker(reg);

          // Check for updates immediately
          reg.update();

          // Listen for new service worker installations
          reg.addEventListener('updatefound', () => {
            const newWorker = reg.installing;
            if (newWorker) {
              console.log('🔄 New Service Worker found, installing...');
              
              newWorker.addEventListener('statechange', () => {
                console.log('🔄 SW state changed to:', newWorker.state);
                
                if (newWorker.state === 'installed') {
                  if (navigator.serviceWorker.controller) {
                    // New service worker available
                    console.log('🆕 New Service Worker available');
                    setUpdateAvailable(true);
                  } else {
                    // First time install
                    console.log('🎉 Service Worker installed for the first time');
                  }
                }
                
                if (newWorker.state === 'activated') {
                  console.log('🎯 New Service Worker activated');
                  getSwVersionFromWorker(reg);
                }
              });
            }
          });

          // Listen for controlling service worker changes
          navigator.serviceWorker.addEventListener('controllerchange', () => {
            console.log('🔄 Service Worker controller changed - reloading page');
            window.location.reload();
          });

          // Listen for messages from service worker
          navigator.serviceWorker.addEventListener('message', (event) => {
            const { type, payload } = event.data || {};
            console.log('📨 Message from SW:', type, payload);
            
            if (type === 'VERSION_RESPONSE') {
              setSwVersion(payload.version);
            }
          });

        } catch (error) {
          console.warn('❌ Service Worker registration failed:', error);
          setRegistrationError(error instanceof Error ? error.message : 'Unknown registration error');
          setIsRegistered(false);
          setRegistration(null);
        }
      };

      registerServiceWorker();
    }

    // Handle install prompt
    const handleBeforeInstallPrompt = (e: Event) => {
      console.log('💡 App install prompt available');
      e.preventDefault();
      setDeferredPrompt(e);
      setIsInstallable(true);
    };

    // Handle app installed
    const handleAppInstalled = () => {
      console.log('🎉 App installed successfully');
      setIsAppInstalled(true);
      setIsInstallable(false);
      setDeferredPrompt(null);
    };

    // Check if app is already installed
    const checkIfInstalled = () => {
      const isInStandaloneMode = window.matchMedia('(display-mode: standalone)').matches;
      const isInWebAppMode = 'standalone' in navigator && (navigator as any).standalone;
      const isInstalled = isInStandaloneMode || isInWebAppMode;
      setIsAppInstalled(isInstalled);
      
      if (isInstalled) {
        console.log('📱 App is already installed');
      }
    };

    // Online/offline status handlers
    const handleOnline = () => {
      console.log('🌐 App is back online');
      setIsOnline(true);
    };
    
    const handleOffline = () => {
      console.log('📱 App is now offline');
      setIsOnline(false);
    };

    // Add event listeners
    window.addEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
    window.addEventListener('appinstalled', handleAppInstalled);
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    
    checkIfInstalled();

    // Check for updates periodically (every 30 minutes)
    const updateCheckInterval = setInterval(() => {
      if (registration) {
        console.log('🔄 Checking for Service Worker updates...');
        registration.update();
      }
    }, 30 * 60 * 1000);

    // Cleanup
    return () => {
      window.removeEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
      window.removeEventListener('appinstalled', handleAppInstalled);
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
      clearInterval(updateCheckInterval);
    };
  }, []);

  // Helper function to get SW version
  const getSwVersionFromWorker = async (reg: ServiceWorkerRegistration) => {
    if (reg.active) {
      try {
        const messageChannel = new MessageChannel();
        messageChannel.port1.onmessage = (event) => {
          if (event.data.version) {
            setSwVersion(event.data.version);
            console.log('📋 Service Worker version:', event.data.version);
          }
        };
        
        reg.active.postMessage({ type: 'GET_VERSION' }, [messageChannel.port2]);
      } catch (error) {
        console.warn('⚠️ Failed to get SW version:', error);
      }
    }
  };

  const installApp = async () => {
    if (!deferredPrompt) {
      console.log('❌ No install prompt available');
      return;
    }

    try {
      console.log('📲 Prompting user to install app...');
      const result = await deferredPrompt.prompt();
      console.log('📲 Install prompt result:', result);
      
      if (result.outcome === 'accepted') {
        console.log('✅ User accepted the install prompt');
        setIsAppInstalled(true);
      } else {
        console.log('❌ User dismissed the install prompt');
      }
      
      setDeferredPrompt(null);
      setIsInstallable(false);
    } catch (error) {
      console.error('❌ Error during app installation:', error);
    }
  };

  const applyUpdate = async () => {
    if (!registration) {
      console.log('❌ No service worker registration available for update - reloading page');
      window.location.reload();
      return;
    }

    try {
      const waitingWorker = registration.waiting;
      if (waitingWorker) {
        console.log('🔄 Applying pending Service Worker update...');
        waitingWorker.postMessage({ type: 'SKIP_WAITING' });
        // The controllerchange event will trigger a reload
      } else {
        console.log('🔄 Forcing Service Worker update check...');
        await registration.update();
        window.location.reload();
      }
    } catch (error) {
      console.error('❌ Error applying update:', error);
      // Fallback: just reload the page
      window.location.reload();
    }
  };

  const clearCache = async () => {
    try {
      if (registration && registration.active) {
        // Ask service worker to clear cache
        const messageChannel = new MessageChannel();
        messageChannel.port1.onmessage = (event) => {
          if (event.data.success) {
            console.log('✅ Cache cleared via Service Worker');
          }
        };
        
        registration.active.postMessage({ type: 'CLEAR_CACHE' }, [messageChannel.port2]);
      } else if ('caches' in window) {
        // Fallback: clear cache directly
        const cacheNames = await caches.keys();
        await Promise.all(
          cacheNames.map(cacheName => caches.delete(cacheName))
        );
        console.log('✅ All caches cleared directly');
      } else {
        console.log('❌ Cache API not supported');
      }
    } catch (error) {
      console.error('❌ Error clearing cache:', error);
    }
  };

  const getSwVersion = async (): Promise<string> => {
    if (swVersion) {
      return swVersion;
    }
    
    if (registration) {
      await getSwVersionFromWorker(registration);
      return swVersion || 'unknown';
    }
    
    return 'not-registered';
  };

  return {
    isSupported,
    isRegistered,
    updateAvailable,
    isInstallable,
    isOnline,
    isAppInstalled,
    registration,
    registrationError,
    swVersion,
    installApp,
    applyUpdate,
    clearCache,
    getSwVersion
  };
}