import { useState, useEffect } from 'react';
import { itinerary as initialItinerary, DayPlan, Activity } from '../data/itinerary';

const STORAGE_KEY = 'honeymoon-itinerary-edits';

interface ItineraryEdit {
  date: string;
  activityId: string;
  changes: Partial<Activity>;
}

interface UserActivity extends Omit<Activity, 'id'> {
  id: string;
  isUserCreated: true;
  createdAt: string;
}

interface StoredData {
  edits: ItineraryEdit[];
  userActivities: { [date: string]: UserActivity[] };
  lastModified: string;
}

export function useItinerary() {
  const [itineraryData, setItineraryData] = useState<DayPlan[]>(initialItinerary);
  const [edits, setEdits] = useState<ItineraryEdit[]>([]);
  const [userActivities, setUserActivities] = useState<{ [date: string]: UserActivity[] }>({});

  // Load from localStorage on mount
  useEffect(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEY);
      if (stored) {
        const data: StoredData = JSON.parse(stored);
        setEdits(data.edits || []);
        setUserActivities(data.userActivities || {});
      }
    } catch (error) {
      console.error('Error loading itinerary data:', error);
    }
  }, []);

  // Apply edits and user activities to itinerary
  useEffect(() => {
    const modifiedItinerary = initialItinerary.map(day => {
      // Apply edits to existing activities
      const modifiedActivities = day.activities.map(activity => {
        const edit = edits.find(e => e.date === day.date && e.activityId === activity.id);
        return edit ? { ...activity, ...edit.changes } : activity;
      });

      // Add user-created activities
      const userDayActivities = userActivities[day.date] || [];
      const allActivities = [...modifiedActivities, ...userDayActivities];

      // Sort by time
      allActivities.sort((a, b) => a.time.localeCompare(b.time));

      return {
        ...day,
        activities: allActivities
      };
    });

    setItineraryData(modifiedItinerary);
  }, [edits, userActivities]);

  // Save to localStorage
  const saveToStorage = (newEdits: ItineraryEdit[], newUserActivities: { [date: string]: UserActivity[] }) => {
    try {
      const data: StoredData = {
        edits: newEdits,
        userActivities: newUserActivities,
        lastModified: new Date().toISOString()
      };
      localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
    } catch (error) {
      console.error('Error saving itinerary data:', error);
    }
  };

  const updateActivity = (date: string, activityId: string, changes: Partial<Activity>) => {
    const newEdits = edits.filter(e => !(e.date === date && e.activityId === activityId));
    newEdits.push({ date, activityId, changes });
    setEdits(newEdits);
    saveToStorage(newEdits, userActivities);
  };

  const addUserActivity = (date: string, activity: Omit<Activity, 'id'>) => {
    const newActivity: UserActivity = {
      ...activity,
      id: `user-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      isUserCreated: true,
      createdAt: new Date().toISOString()
    };

    const newUserActivities = {
      ...userActivities,
      [date]: [...(userActivities[date] || []), newActivity]
    };

    setUserActivities(newUserActivities);
    saveToStorage(edits, newUserActivities);
  };

  const deleteUserActivity = (date: string, activityId: string) => {
    const dayActivities = userActivities[date] || [];
    const newDayActivities = dayActivities.filter(a => a.id !== activityId);
    
    const newUserActivities = {
      ...userActivities,
      [date]: newDayActivities
    };

    setUserActivities(newUserActivities);
    saveToStorage(edits, newUserActivities);
  };

  const moveActivity = (sourceDate: string, targetDate: string, activityId: string) => {
    // Find the activity
    const sourceDay = itineraryData.find(d => d.date === sourceDate);
    const activity = sourceDay?.activities.find(a => a.id === activityId);
    
    if (!activity) return;

    // If it's a user-created activity, move it
    if ('isUserCreated' in activity && activity.isUserCreated) {
      deleteUserActivity(sourceDate, activityId);
      const { id, isUserCreated, createdAt, ...activityData } = activity as UserActivity;
      addUserActivity(targetDate, activityData);
    } else {
      // For original activities, we can only create a copy and hide the original
      const { id, ...activityData } = activity;
      addUserActivity(targetDate, activityData);
      // Hide original activity by marking it as deleted
      updateActivity(sourceDate, activityId, { isDeleted: true } as any);
    }
  };

  const resetItinerary = () => {
    setEdits([]);
    setUserActivities({});
    localStorage.removeItem(STORAGE_KEY);
  };

  const exportItinerary = () => {
    const data = {
      edits,
      userActivities,
      lastModified: new Date().toISOString()
    };
    return JSON.stringify(data, null, 2);
  };

  return {
    itinerary: itineraryData,
    updateActivity,
    addUserActivity,
    deleteUserActivity,
    moveActivity,
    resetItinerary,
    exportItinerary,
    hasChanges: edits.length > 0 || Object.keys(userActivities).some(date => userActivities[date].length > 0)
  };
}