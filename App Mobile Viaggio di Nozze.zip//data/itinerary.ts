export interface Activity {
  id: string;
  time: string;
  title: string;
  description?: string;
  location?: string;
  type: 'flight' | 'hotel' | 'checkin' | 'checkout' | 'transport' | 'activity' | 'exploration' | 'meal' | 'safari' | 'ferry' | 'wedding';
  duration?: string;
  notes?: string;
  isPlaceholder?: boolean;
  userNotes?: string;
  mapLink?: string;
  travelTime?: {
    from: string;
    to: string;
    duration: string;
    distance?: string;
  };
}

export interface DayPlan {
  date: string;
  dayName: string;
  location: string;
  weather?: string;
  activities: Activity[];
}

export const flights = [
  {
    date: '30 Giu',
    route: 'Milano Malpensa → Addis Abeba',
    flight: 'ET 707',
    dep: '23:40',
    arr: '07:15+1'
  },
  {
    date: '01 Lug',
    route: 'Addis Abeba → Cape Town',
    flight: 'ET 847',
    dep: '09:00',
    arr: '14:30'
  },
  {
    date: '05 Lug',
    route: 'Cape Town → Skukuza',
    flight: 'SA 8121',
    dep: '10:30',
    arr: '12:55'
  },
  {
    date: '11 Lug',
    route: 'Johannesburg → Mahe',
    flight: 'ET 858',
    dep: '13:50',
    arr: '20:45'
  },
  {
    date: '21 Lug',
    route: 'Mahe → Addis Abeba',
    flight: 'ET 859',
    dep: '17:20',
    arr: '20:05'
  },
  {
    date: '22 Lug',
    route: 'Addis Abeba → Milano Malpensa',
    flight: 'ET 706',
    dep: '00:15',
    arr: '05:50'
  }
];

export const itinerary: DayPlan[] = [
  {
    date: '2025-06-27',
    dayName: 'Venerdì',
    location: 'Milano, Italia',
    weather: '💒 Giorno del Matrimonio',
    activities: [
      {
        id: 'wedding-1',
        time: '15:00',
        title: 'Matrimonio 💒',
        description: 'Il nostro giorno speciale! Cerimonia e festa di nozze',
        location: 'Milano',
        type: 'wedding',
        duration: '8h',
        mapLink: 'https://maps.app.goo.gl/Milano'
      }
    ]
  },
  {
    date: '2025-06-28',
    dayName: 'Sabato',
    location: 'Milano, Italia',
    weather: '💕 Post Matrimonio',
    activities: [
      {
        id: 'post-wedding-1',
        time: '10:00',
        title: 'Relax Post-Matrimonio',
        description: 'Giornata di riposo dopo la festa',
        location: 'Milano',
        type: 'activity',
        duration: '6h'
      },
      {
        id: 'post-wedding-2',
        time: '18:00',
        title: 'Preparativi Viaggio',
        description: 'Ultimazione bagagli e preparativi per il viaggio di nozze',
        location: 'Milano',
        type: 'activity',
        duration: '3h'
      }
    ]
  },
  {
    date: '2025-06-29',
    dayName: 'Domenica',
    location: 'Milano, Italia',
    weather: '✈️ Pre-Partenza',
    activities: [
      {
        id: 'pre-departure-1',
        time: '09:00',
        title: 'Ultimi Preparativi',
        description: 'Check-in online e preparativi finali',
        location: 'Milano',
        type: 'activity',
        duration: '3h'
      },
      {
        id: 'pre-departure-2',
        time: '20:00',
        title: 'Cena Pre-Viaggio',
        description: 'Ultima cena italiana prima della partenza',
        location: 'Milano',
        type: 'meal',
        duration: '2h'
      }
    ]
  },
  {
    date: '2025-06-30',
    dayName: 'Lunedì',
    location: 'Milano Malpensa',
    activities: [
      {
        id: '1',
        time: '23:40',
        title: 'Partenza da Milano Malpensa',
        description: 'Volo ET 707 per Addis Abeba',
        location: 'Aeroporto Milano Malpensa',
        type: 'flight',
        duration: '7h 35min',
        mapLink: 'https://maps.app.goo.gl/milano-malpensa-airport'
      }
    ]
  },
  {
    date: '2025-07-01',
    dayName: 'Martedì',
    location: 'Cape Town, Sudafrica',
    weather: '☀️ 18°C, Soleggiato',
    activities: [
      {
        id: '2',
        time: '07:15',
        title: 'Arrivo ad Addis Abeba',
        description: 'Scalo tecnico',
        location: 'Aeroporto Addis Abeba',
        type: 'flight',
        mapLink: 'https://maps.app.goo.gl/addis-ababa-airport'
      },
      {
        id: '3',
        time: '09:00',
        title: 'Volo per Cape Town',
        description: 'Volo ET 847',
        location: 'Addis Abeba → Cape Town',
        type: 'flight',
        duration: '5h 30min'
      },
      {
        id: '4',
        time: '14:30',
        title: 'Arrivo a Cape Town',
        description: 'Atterraggio all\'aeroporto internazionale di Cape Town',
        location: 'Aeroporto Cape Town',
        type: 'flight',
        mapLink: 'https://maps.app.goo.gl/cape-town-airport'
      },
      {
        id: '5',
        time: '15:30',
        title: 'Ritiro Auto EUROPCAR',
        description: 'Toyota Corolla Quest o similare - 5 giorni',
        location: 'Aeroporto Cape Town',
        type: 'transport',
        duration: '1h',
        mapLink: 'https://maps.app.goo.gl/cape-town-airport-europcar'
      },
      {
        id: '6',
        time: '17:00',
        title: 'Check-in Hotel',
        description: 'Aha Harbour Bridge Hotel & Suites - 1 Dockrail Rd, Foreshore',
        location: '1 Dockrail Rd, Foreshore, Cape Town',
        type: 'checkin',
        mapLink: 'https://maps.app.goo.gl/aha-harbour-bridge-hotel'
      },
      {
        id: '7',
        time: '18:00',
        title: 'Victoria & Alfred Waterfront',
        description: 'Zona di edifici moderni con affaccio sull\'oceano. Centro commerciale, negozi, ristoranti e Two Oceans Aquarium. Bellissimo al tramonto!',
        location: 'Victoria & Alfred Waterfront',
        type: 'exploration',
        duration: '3h',
        mapLink: 'https://maps.app.goo.gl/va-waterfront-cape-town'
      },
      {
        id: '8',
        time: '19:30',
        title: 'Cena al Waterfront',
        description: 'Cena in uno dei ristoranti del V&A Waterfront',
        location: 'Victoria & Alfred Waterfront',
        type: 'meal',
        duration: '2h',
        mapLink: 'https://maps.app.goo.gl/va-waterfront-restaurants'
      },
      {
        id: '9',
        time: '21:30',
        title: 'Table Mountain (opzionale)',
        description: 'Funivia Table Mountain se aperta e condizioni permettono',
        location: 'Table Mountain',
        type: 'activity',
        isPlaceholder: true,
        mapLink: 'https://maps.app.goo.gl/table-mountain-cableway'
      }
    ]
  },
  {
    date: '2025-07-02',
    dayName: 'Mercoledì',
    location: 'Cape Town - Peninsula Tour',
    weather: '☀️ 19°C, Soleggiato',
    activities: [
      {
        id: '10',
        time: '08:00',
        title: 'Colazione in Hotel',
        description: 'Colazione inclusa nel soggiorno',
        location: 'Aha Harbour Bridge Hotel',
        type: 'meal',
        mapLink: 'https://maps.app.goo.gl/aha-harbour-bridge-hotel'
      },
      {
        id: '11',
        time: '09:00',
        title: 'Partenza Peninsula Tour',
        description: 'Inizio del tour della penisola del Capo',
        location: 'Cape Town',
        type: 'transport',
        duration: '30min'
      },
      {
        id: '12',
        time: '09:30',
        title: 'Muizenberg Beach',
        description: 'Spiaggia caratterizzata dalle famose case colorate',
        location: 'Muizenberg',
        type: 'exploration',
        duration: '45min',
        mapLink: 'https://maps.app.goo.gl/muizenberg-beach-colored-houses'
      },
      {
        id: '13',
        time: '10:30',
        title: 'Kalk Bay',
        description: 'Pittoresco paesino con comunità "coloured" integra, pieno di bar e antiquariato',
        location: 'Kalk Bay',
        type: 'exploration',
        duration: '1h',
        mapLink: 'https://maps.app.goo.gl/kalk-bay-harbor'
      },
      {
        id: '14',
        time: '11:45',
        title: 'Fish Hoek',
        description: 'Tappa veloce per ammirare la spiaggia frequentata dalle famiglie locali',
        location: 'Fish Hoek',
        type: 'exploration',
        duration: '30min',
        mapLink: 'https://maps.app.goo.gl/fish-hoek-beach'
      },
      {
        id: '15',
        time: '12:30',
        title: 'Simon\'s Town',
        description: 'Cittadina storica utilizzata come attracco navale. Centro con antiquariato, musei e accesso a Boulders Beach',
        location: 'Simon\'s Town',
        type: 'exploration',
        duration: '1h 30min',
        mapLink: 'https://maps.app.goo.gl/simons-town-naval-base'
      },
      {
        id: '16',
        time: '14:00',
        title: 'Boulders Beach - Pinguini! 🐧',
        description: 'Spiaggia dei pinguini! Parte del Table Mountain National Park. Ingresso €8/persona',
        location: 'Boulders Beach',
        type: 'activity',
        duration: '1h 30min',
        mapLink: 'https://maps.app.goo.gl/boulders-beach-penguins'
      },
      {
        id: '17',
        time: '16:00',
        title: 'Capo di Buona Speranza',
        description: 'Punto iconico (non il più a sud!). Faro, funicolare, sentieri e spiagge. Diverse spiagge: Witsands, Misty Cliffs, Scarborough, Platboom',
        location: 'Capo di Buona Speranza',
        type: 'exploration',
        duration: '2h',
        mapLink: 'https://maps.app.goo.gl/cape-of-good-hope-point'
      },
      {
        id: '18',
        time: '18:30',
        title: 'Chapman\'s Peak Drive',
        description: 'Una delle strade panoramiche più belle al mondo! 9 km di curve mozzafiato',
        location: 'Chapman\'s Peak Drive',
        type: 'transport',
        duration: '45min',
        mapLink: 'https://maps.app.goo.gl/chapmans-peak-drive'
      },
      {
        id: '19',
        time: '19:15',
        title: 'Hout Bay',
        description: 'Borgo di pescatori. Possibile escursione a Duiker Island (1h) per vedere le otarie',
        location: 'Hout Bay',
        type: 'exploration',
        duration: '1h',
        mapLink: 'https://maps.app.goo.gl/hout-bay-harbor'
      },
      {
        id: '20',
        time: '20:30',
        title: 'Cena a Hout Bay',
        description: 'Cena a base di pesce fresco nel porto',
        location: 'Hout Bay',
        type: 'meal',
        duration: '1h 30min',
        mapLink: 'https://maps.app.goo.gl/hout-bay-restaurants'
      }
    ]
  },
  {
    date: '2025-07-03',
    dayName: 'Giovedì',
    location: 'Cape Town - Centro & Anniversario 💕',
    weather: '⛅ 20°C, Nuvoloso',
    activities: [
      {
        id: '21',
        time: '08:00',
        title: 'Colazione in Hotel',
        description: 'Colazione inclusa nel soggiorno',
        location: 'Aha Harbour Bridge Hotel',
        type: 'meal',
        mapLink: 'https://maps.app.goo.gl/aha-harbour-bridge-hotel'
      },
      {
        id: '22',
        time: '09:30',
        title: 'Centro Storico - Grand Parade',
        description: 'Partenza da Piazza Grand Parade e Castle of Good Hope',
        location: 'Grand Parade',
        type: 'exploration',
        duration: '1h',
        mapLink: 'https://maps.app.goo.gl/grand-parade-cape-town'
      },
      {
        id: '23',
        time: '10:30',
        title: 'Greenmarket Square',
        description: 'Mercato storico passando da Longmarket e Shortmarket Street',
        location: 'Greenmarket Square',
        type: 'exploration',
        duration: '45min',
        mapLink: 'https://maps.app.goo.gl/greenmarket-square-cape-town'
      },
      {
        id: '24',
        time: '11:30',
        title: 'Long Street',
        description: 'Strada iconica piena di negozi, ristoranti e vita notturna',
        location: 'Long Street',
        type: 'exploration',
        duration: '1h',
        mapLink: 'https://maps.app.goo.gl/long-street-cape-town'
      },
      {
        id: '25',
        time: '13:00',
        title: 'Pranzo Anniversary',
        description: 'Pranzo speciale per anniversario fidanzamento! 💕',
        location: 'Long Street',
        type: 'meal',
        duration: '1h 30min',
        mapLink: 'https://maps.app.goo.gl/long-street-restaurants'
      },
      {
        id: '26',
        time: '14:30',
        title: 'Quartiere Bo-Kaap',
        description: 'Ex quartiere schiavi malesi. Case colorate simbolo di libertà. Museo Iziko Bo-Kaap disponibile',
        location: 'Bo-Kaap',
        type: 'exploration',
        duration: '1h 30min',
        mapLink: 'https://maps.app.goo.gl/bo-kaap-cape-town'
      },
      {
        id: '27',
        time: '16:00',
        title: 'Company\'s Garden',
        description: 'Passeggiata rilassante nei giardini storici',
        location: 'Company\'s Garden',
        type: 'exploration',
        duration: '45min',
        mapLink: 'https://maps.app.goo.gl/companys-garden-cape-town'
      },
      {
        id: '28',
        time: '17:00',
        title: 'Giardino Botanico Kirstenbosch',
        description: 'Enorme giardino botanico ai piedi della Table Mountain. Canopy Walk in legno con vista sulla Table Mountain. Biglietto €12',
        location: 'Kirstenbosch',
        type: 'activity',
        duration: '2h',
        mapLink: 'https://maps.app.goo.gl/kirstenbosch-botanical-garden'
      },
      {
        id: '29',
        time: '19:30',
        title: 'Table Mountain al Tramonto',
        description: 'Funivia Table Mountain per il tramonto (prenotare online)',
        location: 'Table Mountain',
        type: 'activity',
        duration: '2h',
        mapLink: 'https://maps.app.goo.gl/table-mountain-cableway'
      }
    ]
  },
  {
    date: '2025-07-04',
    dayName: 'Venerdì',
    location: 'Cape Town - Escursioni',
    weather: '☀️ 22°C, Soleggiato',
    activities: [
      {
        id: '30',
        time: '08:00',
        title: 'Colazione in Hotel',
        description: 'Colazione inclusa nel soggiorno',
        location: 'Aha Harbour Bridge Hotel',
        type: 'meal',
        mapLink: 'https://maps.app.goo.gl/aha-harbour-bridge-hotel'
      },
      {
        id: '31',
        time: '09:00',
        title: 'Partenza per Hermanus',
        description: 'Viaggio verso Hermanus per whale watching',
        location: 'Cape Town → Hermanus',
        type: 'transport',
        duration: '1h 30min',
        travelTime: {
          from: 'Cape Town',
          to: 'Hermanus',
          duration: '1h 30min',
          distance: '120 km'
        }
      },
      {
        id: '32',
        time: '10:30',
        title: 'Whale Watching Hermanus 🐋',
        description: 'Escursione per avvistamento balene (prenotare su gatyourgide.com)',
        location: 'Hermanus',
        type: 'activity',
        duration: '3h',
        mapLink: 'https://maps.app.goo.gl/hermanus-whale-watching'
      },
      {
        id: '33',
        time: '13:30',
        title: 'Pranzo a Hermanus',
        description: 'Pranzo vista oceano dopo il whale watching',
        location: 'Hermanus',
        type: 'meal',
        duration: '1h',
        mapLink: 'https://maps.app.goo.gl/hermanus-restaurants'
      },
      {
        id: '34',
        time: '15:00',
        title: 'Stellenbosch Wine Tour',
        description: 'Visita alle cantine e degustazione vini nella famosa regione vinicola',
        location: 'Stellenbosch',
        type: 'activity',
        duration: '3h',
        mapLink: 'https://maps.app.goo.gl/stellenbosch-wine-route',
        travelTime: {
          from: 'Hermanus',
          to: 'Stellenbosch',
          duration: '1h',
          distance: '80 km'
        }
      },
      {
        id: '35',
        time: '19:00',
        title: 'Cena nelle Wine Lands',
        description: 'Cena in cantina con degustazione vini',
        location: 'Stellenbosch',
        type: 'meal',
        duration: '2h',
        mapLink: 'https://maps.app.goo.gl/stellenbosch-wine-restaurants'
      },
      {
        id: '36',
        time: '21:30',
        title: 'Rientro Hotel',
        description: 'Rientro a Cape Town (opzionale: Lion\'s Head Hiking se energia)',
        location: 'Cape Town',
        type: 'transport',
        duration: '1h',
        travelTime: {
          from: 'Stellenbosch',
          to: 'Cape Town',
          duration: '1h',
          distance: '50 km'
        }
      }
    ]
  },
  {
    date: '2025-07-05',
    dayName: 'Sabato',
    location: 'Kruger National Park, Sudafrica',
    weather: '☀️ 25°C, Soleggiato',
    activities: [
      {
        id: '37',
        time: '08:00',
        title: 'Colazione e Check-out',
        description: 'Ultima colazione a Cape Town',
        location: 'Aha Harbour Bridge Hotel',
        type: 'checkout',
        mapLink: 'https://maps.app.goo.gl/aha-harbour-bridge-hotel'
      },
      {
        id: '38',
        time: '09:00',
        title: 'Rilascio Auto EUROPCAR',
        description: 'Restituzione Toyota Corolla Quest all\'aeroporto',
        location: 'Aeroporto Cape Town',
        type: 'transport',
        mapLink: 'https://maps.app.goo.gl/cape-town-airport-europcar'
      },
      {
        id: '39',
        time: '10:30',
        title: 'Volo per Skukuza',
        description: 'Volo SA 8121 per il Kruger National Park',
        location: 'Cape Town → Skukuza',
        type: 'flight',
        duration: '2h 25min'
      },
      {
        id: '40',
        time: '12:55',
        title: 'Arrivo a Skukuza',
        description: 'Atterraggio aeroporto Skukuza',
        location: 'Aeroporto Skukuza',
        type: 'flight',
        mapLink: 'https://maps.app.goo.gl/skukuza-airport'
      },
      {
        id: '41',
        time: '13:30',
        title: 'Ritiro Auto EUROPCAR',
        description: 'T-ROC o similare - 7 giorni',
        location: 'Aeroporto Skukuza',
        type: 'transport',
        duration: '30min',
        mapLink: 'https://maps.app.goo.gl/skukuza-airport-car-rental'
      },
      {
        id: '42',
        time: '14:30',
        title: 'Trasferimento Hotel',
        description: 'Spostamento verso Kruger Gate Hotel',
        location: 'Skukuza → Kruger Gate',
        type: 'transport',
        duration: '30min',
        travelTime: {
          from: 'Aeroporto Skukuza',
          to: 'Kruger Gate Hotel',
          duration: '30 minuti',
          distance: '20 km'
        }
      },
      {
        id: '43',
        time: '15:00',
        title: 'Check-in Kruger Gate',
        description: 'Camera doppia deluxe in mezza pensione',
        location: 'Kruger Gate Hotel',
        type: 'checkin',
        mapLink: 'https://maps.app.goo.gl/kruger-gate-hotel'
      },
      {
        id: '44',
        time: '16:00',
        title: 'Safari Self-Drive o Piscina',
        description: 'Primo pomeriggio al Kruger: safari autonomo o relax in piscina',
        location: 'Kruger National Park',
        type: 'safari',
        duration: '2h',
        mapLink: 'https://maps.app.goo.gl/kruger-national-park'
      },
      {
        id: '45',
        time: '19:00',
        title: 'Cena in Hotel',
        description: 'Cena inclusa nella mezza pensione',
        location: 'Kruger Gate Hotel',
        type: 'meal',
        mapLink: 'https://maps.app.goo.gl/kruger-gate-hotel'
      }
    ]
  },
  {
    date: '2025-07-06',
    dayName: 'Domenica',
    location: 'Kruger National Park - Rhino Post Safari Lodge',
    weather: '☀️ 28°C, Soleggiato',
    activities: [
      {
        id: '46',
        time: '07:00',
        title: 'Colazione in Hotel',
        description: 'Colazione inclusa nella mezza pensione',
        location: 'Kruger Gate Hotel',
        type: 'meal',
        mapLink: 'https://maps.app.goo.gl/kruger-gate-hotel'
      },
      {
        id: '47',
        time: '08:00',
        title: 'Safari Self-Drive (opzionale)',
        description: 'Safari mattutino autonomo nel Kruger',
        location: 'Kruger National Park',
        type: 'safari',
        duration: '2h',
        isPlaceholder: true,
        mapLink: 'https://maps.app.goo.gl/kruger-national-park'
      },
      {
        id: '48',
        time: '11:00',
        title: 'Check-out Kruger Gate',
        description: 'Partenza verso Rhino Post Safari Lodge',
        location: 'Kruger Gate Hotel',
        type: 'checkout',
        mapLink: 'https://maps.app.goo.gl/kruger-gate-hotel'
      },
      {
        id: '49',
        time: '12:00',
        title: 'Pranzo veloce',
        description: 'Pranzo prima del trasferimento',
        location: 'Kruger Gate',
        type: 'meal',
        duration: '1h'
      },
      {
        id: '50',
        time: '13:00',
        title: 'Trasferimento Rhino Post',
        description: 'Spostamento verso il safari lodge',
        location: 'Kruger Gate → Rhino Post',
        type: 'transport',
        duration: '50min',
        travelTime: {
          from: 'Kruger Gate Hotel',
          to: 'Rhino Post Safari Lodge',
          duration: '50 minuti',
          distance: '36 km'
        }
      },
      {
        id: '51',
        time: '14:00',
        title: 'Check-in Rhino Post Safari Lodge',
        description: 'Camera doppia Bush Suite in pensione completa',
        location: 'Rhino Post Safari Lodge',
        type: 'checkin',
        mapLink: 'https://maps.app.goo.gl/rhino-post-safari-lodge'
      },
      {
        id: '52',
        time: '15:00',
        title: 'Safari Pomeridiano Organizzato',
        description: 'Game drive professionale nel Kruger National Park',
        location: 'Kruger National Park',
        type: 'safari',
        duration: '3h',
        mapLink: 'https://maps.app.goo.gl/kruger-national-park'
      },
      {
        id: '53',
        time: '19:00',
        title: 'Cena al Lodge',
        description: 'Cena inclusa nella pensione completa',
        location: 'Rhino Post Safari Lodge',
        type: 'meal',
        mapLink: 'https://maps.app.goo.gl/rhino-post-safari-lodge'
      }
    ]
  },
  {
    date: '2025-07-07',
    dayName: 'Lunedì',
    location: 'Kruger National Park - Shiduli Game Lodge',
    weather: '☀️ 30°C, Soleggiato',
    activities: [
      {
        id: '54',
        time: '06:00',
        title: 'Safari Mattutino Organizzato',
        description: 'Game drive all\'alba nel Kruger National Park',
        location: 'Kruger National Park',
        type: 'safari',
        duration: '3h',
        mapLink: 'https://maps.app.goo.gl/kruger-national-park'
      },
      {
        id: '55',
        time: '09:30',
        title: 'Colazione al Lodge',
        description: 'Colazione inclusa nella pensione completa',
        location: 'Rhino Post Safari Lodge',
        type: 'meal',
        mapLink: 'https://maps.app.goo.gl/rhino-post-safari-lodge'
      },
      {
        id: '56',
        time: '11:00',
        title: 'Check-out Rhino Post',
        description: 'Partenza verso Shiduli Private Game Lodge',
        location: 'Rhino Post Safari Lodge',
        type: 'checkout',
        mapLink: 'https://maps.app.goo.gl/rhino-post-safari-lodge'
      },
      {
        id: '57',
        time: '11:30',
        title: 'Trasferimento Shiduli',
        description: 'Lungo spostamento verso Shiduli Private Game Lodge',
        location: 'Rhino Post → Shiduli',
        type: 'transport',
        duration: '3h 30min',
        travelTime: {
          from: 'Rhino Post Safari Lodge',
          to: 'Shiduli Private Game Lodge',
          duration: '3 ore 34 minuti',
          distance: '202 km'
        }
      },
      {
        id: '58',
        time: '15:00',
        title: 'Check-in Shiduli Game Lodge',
        description: 'Camera doppia Luxury Suite in pensione completa',
        location: 'Shiduli Private Game Lodge',
        type: 'checkin',
        mapLink: 'https://maps.app.goo.gl/shiduli-private-game-lodge'
      },
      {
        id: '59',
        time: '16:00',
        title: 'Game Drive Pomeridiano',
        description: 'Safari nella riserva privata Shiduli',
        location: 'Shiduli Private Game Reserve',
        type: 'safari',
        duration: '3h',
        mapLink: 'https://maps.app.goo.gl/shiduli-private-game-reserve'
      },
      {
        id: '60',
        time: '19:30',
        title: 'Cena al Lodge',
        description: 'Cena inclusa nella pensione completa',
        location: 'Shiduli Private Game Lodge',
        type: 'meal',
        mapLink: 'https://maps.app.goo.gl/shiduli-private-game-lodge'
      }
    ]
  },
  {
    date: '2025-07-08',
    dayName: 'Martedì',
    location: 'Kruger National Park - Shiduli Game Lodge',
    weather: '☀️ 29°C, Soleggiato',
    activities: [
      {
        id: '61',
        time: '06:00',
        title: 'Game Drive Mattutino',
        description: 'Safari all\'alba nella riserva privata',
        location: 'Shiduli Private Game Reserve',
        type: 'safari',
        duration: '3h',
        mapLink: 'https://maps.app.goo.gl/shiduli-private-game-reserve'
      },
      {
        id: '62',
        time: '09:30',
        title: 'Colazione al Lodge',
        description: 'Colazione inclusa nella pensione completa',
        location: 'Shiduli Private Game Lodge',
        type: 'meal',
        mapLink: 'https://maps.app.goo.gl/shiduli-private-game-lodge'
      },
      {
        id: '63',
        time: '11:00',
        title: 'Tempo libero',
        description: 'Relax al lodge, piscina e spa',
        location: 'Shiduli Private Game Lodge',
        type: 'activity',
        mapLink: 'https://maps.app.goo.gl/shiduli-private-game-lodge'
      },
      {
        id: '64',
        time: '16:00',
        title: 'Game Drive Pomeridiano',
        description: 'Secondo safari nella riserva privata',
        location: 'Shiduli Private Game Reserve',
        type: 'safari',
        duration: '3h',
        mapLink: 'https://maps.app.goo.gl/shiduli-private-game-reserve'
      },
      {
        id: '65',
        time: '19:30',
        title: 'Cena al Lodge',
        description: 'Cena inclusa nella pensione completa',
        location: 'Shiduli Private Game Lodge',
        type: 'meal',
        mapLink: 'https://maps.app.goo.gl/shiduli-private-game-lodge'
      }
    ]
  },
  {
    date: '2025-07-09',
    dayName: 'Mercoledì',
    location: 'Graskop, Sudafrica',
    weather: '🌤️ 24°C, Parz. Nuvoloso',
    activities: [
      {
        id: '66',
        time: '06:00',
        title: 'Game Drive Mattutino Finale',
        description: 'Ultimo safari a Shiduli',
        location: 'Shiduli Private Game Reserve',
        type: 'safari',
        duration: '2h',
        mapLink: 'https://maps.app.goo.gl/shiduli-private-game-reserve'
      },
      {
        id: '67',
        time: '08:30',
        title: 'Colazione e Check-out',
        description: 'Ultima colazione a Shiduli',
        location: 'Shiduli Private Game Lodge',
        type: 'checkout',
        mapLink: 'https://maps.app.goo.gl/shiduli-private-game-lodge'
      },
      {
        id: '68',
        time: '09:30',
        title: 'Trasferimento Graskop',
        description: 'Spostamento verso Graskop con tappa al Blyde River Canyon',
        location: 'Shiduli → Graskop',
        type: 'transport',
        duration: '2h',
        travelTime: {
          from: 'Shiduli Private Game Lodge',
          to: 'Blyde River Canyon',
          duration: '1 ora 30 minuti',
          distance: '100 km'
        }
      },
      {
        id: '69',
        time: '11:30',
        title: 'Blyde River Canyon',
        description: 'Visita alle cascate Berlin Falls e Lisbon Falls (92m)',
        location: 'Blyde River Canyon',
        type: 'exploration',
        duration: '2h',
        mapLink: 'https://maps.app.goo.gl/blyde-river-canyon-viewpoints'
      },
      {
        id: '70',
        time: '14:00',
        title: 'Check-in Graskop Hotel',
        description: 'Camera doppia standard in pernottamento e prima colazione',
        location: 'Graskop Hotel',
        type: 'checkin',
        mapLink: 'https://maps.app.goo.gl/graskop-hotel'
      },
      {
        id: '71',
        time: '15:00',
        title: 'Pranzo a Graskop',
        description: 'Pranzo in centro dopo il check-in',
        location: 'Graskop',
        type: 'meal',
        duration: '1h',
        mapLink: 'https://maps.app.goo.gl/graskop-restaurants'
      },
      {
        id: '72',
        time: '16:30',
        title: 'Tempo libero',
        description: 'Esplorazione di Graskop e dintorni',
        location: 'Graskop',
        type: 'exploration',
        duration: '2h',
        isPlaceholder: true,
        mapLink: 'https://maps.app.goo.gl/graskop-town-center'
      },
      {
        id: '73',
        time: '19:00',
        title: 'Cena libera',
        description: 'Cena in un ristorante locale',
        location: 'Graskop',
        type: 'meal',
        mapLink: 'https://maps.app.goo.gl/graskop-restaurants'
      }
    ]
  },
  {
    date: '2025-07-10',
    dayName: 'Giovedì',
    location: 'Johannesburg, Sudafrica',
    weather: '☀️ 20°C, Soleggiato',
    activities: [
      {
        id: '74',
        time: '08:00',
        title: 'Colazione e Check-out',
        description: 'Colazione in hotel e partenza per Johannesburg',
        location: 'Graskop Hotel',
        type: 'checkout',
        mapLink: 'https://maps.app.goo.gl/graskop-hotel'
      },
      {
        id: '75',
        time: '09:00',
        title: 'Punti Panoramici Blyde Canyon',
        description: 'Three Rondavels, Bourke\'s Luck Potholes, God\'s Window',
        location: 'Blyde River Canyon',
        type: 'exploration',
        duration: '3h',
        mapLink: 'https://maps.app.goo.gl/three-rondavels-viewpoint'
      },
      {
        id: '76',
        time: '12:30',
        title: 'Pranzo a Graskop',
        description: 'Pranzo prima del lungo viaggio verso Johannesburg',
        location: 'Graskop',
        type: 'meal',
        duration: '1h',
        mapLink: 'https://maps.app.goo.gl/graskop-restaurants'
      },
      {
        id: '77',
        time: '14:00',
        title: 'Viaggio verso Johannesburg',
        description: 'Lungo trasferimento verso l\'aeroporto di Johannesburg',
        location: 'Graskop → Johannesburg',
        type: 'transport',
        duration: '5h',
        travelTime: {
          from: 'Graskop',
          to: 'Aeroporto OR Tambo Johannesburg',
          duration: '5 ore',
          distance: '450 km'
        }
      },
      {
        id: '78',
        time: '19:00',
        title: 'Rilascio Auto EUROPCAR',
        description: 'Restituzione T-ROC all\'aeroporto. Drop Off Fee ZAR 1.490',
        location: 'Aeroporto OR Tambo',
        type: 'transport',
        mapLink: 'https://maps.app.goo.gl/or-tambo-airport-car-rental'
      },
      {
        id: '79',
        time: '20:00',
        title: 'Check-in Hotel Aeroporto',
        description: 'Pernottamento in hotel vicino all\'aeroporto',
        location: 'Hotel Aeroporto Johannesburg',
        type: 'checkin',
        mapLink: 'https://maps.app.goo.gl/or-tambo-airport-hotels'
      },
      {
        id: '80',
        time: '21:00',
        title: 'Cena in Hotel',
        description: 'Cena in hotel prima del volo per le Seychelles',
        location: 'Hotel Aeroporto',
        type: 'meal'
      }
    ]
  },
  {
    date: '2025-07-11',
    dayName: 'Venerdì',
    location: 'Seychelles - Mahé',
    weather: '🌴 30°C, Tropicale',
    activities: [
      {
        id: '81',
        time: '08:00',
        title: 'Colazione e Check-out',
        description: 'Colazione in hotel e trasferimento aeroporto',
        location: 'Hotel Aeroporto Johannesburg',
        type: 'checkout'
      },
      {
        id: '82',
        time: '13:50',
        title: 'Volo per le Seychelles',
        description: 'Volo ET 858 Johannesburg → Mahé',
        location: 'Johannesburg → Mahé',
        type: 'flight',
        duration: '4h 55min'
      },
      {
        id: '83',
        time: '20:45',
        title: 'Arrivo a Mahé',
        description: 'Atterraggio all\'aeroporto internazionale delle Seychelles',
        location: 'Aeroporto Seychelles',
        type: 'flight',
        mapLink: 'https://maps.app.goo.gl/seychelles-international-airport'
      },
      {
        id: '84',
        time: '21:30',
        title: 'Trasferimento Hotel',
        description: 'Trasferimento all\'hotel su Mahé',
        location: 'Aeroporto → Hotel Mahé',
        type: 'transport',
        duration: '30min'
      },
      {
        id: '85',
        time: '22:00',
        title: 'Check-in Hotel Paradise Sun',
        description: 'Camera vista mare in mezza pensione',
        location: 'Paradise Sun Hotel, Praslin',
        type: 'checkin',
        mapLink: 'https://maps.app.goo.gl/paradise-sun-hotel-praslin'
      }
    ]
  },
  {
    date: '2025-07-12',
    dayName: 'Sabato',
    location: 'Seychelles - Praslin',
    weather: '🌴 29°C, Soleggiato',
    activities: [
      {
        id: '86',
        time: '08:00',
        title: 'Colazione in Hotel',
        description: 'Colazione inclusa nella mezza pensione',
        location: 'Paradise Sun Hotel',
        type: 'meal',
        mapLink: 'https://maps.app.goo.gl/paradise-sun-hotel-praslin'
      },
      {
        id: '87',
        time: '10:00',
        title: 'Spiaggia Anse Lazio',
        description: 'Una delle spiagge più belle al mondo! Sabbia bianca e acqua cristallina',
        location: 'Anse Lazio, Praslin',
        type: 'activity',
        duration: '4h',
        mapLink: 'https://maps.app.goo.gl/anse-lazio-beach-praslin'
      },
      {
        id: '88',
        time: '15:00',
        title: 'Vallée de Mai',
        description: 'Patrimonio UNESCO. Foresta preistorica con Coco de Mer',
        location: 'Vallée de Mai, Praslin',
        type: 'exploration',
        duration: '2h',
        mapLink: 'https://maps.app.goo.gl/vallee-de-mai-praslin'
      },
      {
        id: '89',
        time: '19:00',
        title: 'Cena in Hotel',
        description: 'Cena inclusa nella mezza pensione',
        location: 'Paradise Sun Hotel',
        type: 'meal',
        mapLink: 'https://maps.app.goo.gl/paradise-sun-hotel-praslin'
      }
    ]
  },
  {
    date: '2025-07-13',
    dayName: 'Domenica',
    location: 'Seychelles - La Digue',
    weather: '🌴 28°C, Soleggiato',
    activities: [
      {
        id: '90',
        time: '08:00',
        title: 'Colazione in Hotel',
        description: 'Colazione inclusa nella mezza pensione',
        location: 'Paradise Sun Hotel',
        type: 'meal'
      },
      {
        id: '91',
        time: '09:00',
        title: 'Traghetto per La Digue',
        description: 'Escursione giornaliera all\'isola di La Digue',
        location: 'Praslin → La Digue',
        type: 'ferry',
        duration: '30min',
        mapLink: 'https://maps.app.goo.gl/la-digue-ferry-terminal'
      },
      {
        id: '92',
        time: '10:00',
        title: 'Noleggio Bici a La Digue',
        description: 'Esplorazione dell\'isola in bicicletta (no auto!)',
        location: 'La Digue',
        type: 'transport',
        duration: '8h',
        mapLink: 'https://maps.app.goo.gl/la-digue-bike-rental'
      },
      {
        id: '93',
        time: '11:00',
        title: 'Anse Source d\'Argent',
        description: 'Spiaggia iconica con rocce granitiche. La più fotografata al mondo!',
        location: 'Anse Source d\'Argent, La Digue',
        type: 'activity',
        duration: '3h',
        mapLink: 'https://maps.app.goo.gl/anse-source-dargent-la-digue'
      },
      {
        id: '94',
        time: '14:30',
        title: 'Pranzo a La Digue',
        description: 'Pranzo di pesce fresco con vista oceano',
        location: 'La Digue',
        type: 'meal',
        duration: '1h 30min',
        mapLink: 'https://maps.app.goo.gl/la-digue-restaurants'
      },
      {
        id: '95',
        time: '16:30',
        title: 'Anse Coco',
        description: 'Spiaggia selvaggia raggiungibile solo a piedi',
        location: 'Anse Coco, La Digue',
        type: 'exploration',
        duration: '1h 30min',
        mapLink: 'https://maps.app.goo.gl/anse-coco-la-digue'
      },
      {
        id: '96',
        time: '18:30',
        title: 'Rientro a Praslin',
        description: 'Traghetto di ritorno a Praslin',
        location: 'La Digue → Praslin',
        type: 'ferry',
        duration: '30min'
      },
      {
        id: '97',
        time: '19:30',
        title: 'Cena in Hotel',
        description: 'Cena inclusa nella mezza pensione',
        location: 'Paradise Sun Hotel',
        type: 'meal'
      }
    ]
  },
  {
    date: '2025-07-14',
    dayName: 'Lunedì',
    location: 'Seychelles - Praslin',
    weather: '🌴 30°C, Soleggiato',
    activities: [
      {
        id: '98',
        time: '08:00',
        title: 'Colazione in Hotel',
        description: 'Colazione inclusa nella mezza pensione',
        location: 'Paradise Sun Hotel',
        type: 'meal'
      },
      {
        id: '99',
        time: '10:00',
        title: 'Relax in Spiaggia',
        description: 'Giornata di relax sulla spiaggia dell\'hotel',
        location: 'Paradise Sun Hotel Beach',
        type: 'activity',
        duration: '6h',
        mapLink: 'https://maps.app.goo.gl/paradise-sun-hotel-beach'
      },
      {
        id: '100',
        time: '16:00',
        title: 'Snorkeling (opzionale)',
        description: 'Snorkeling nelle acque cristalline di Praslin',
        location: 'Anse Volbert, Praslin',
        type: 'activity',
        duration: '2h',
        isPlaceholder: true,
        mapLink: 'https://maps.app.goo.gl/anse-volbert-snorkeling'
      },
      {
        id: '101',
        time: '19:00',
        title: 'Cena in Hotel',
        description: 'Cena inclusa nella mezza pensione',
        location: 'Paradise Sun Hotel',
        type: 'meal'
      }
    ]
  },
  {
    date: '2025-07-15',
    dayName: 'Martedì',
    location: 'Seychelles - Praslin',
    weather: '🌴 29°C, Soleggiato',
    activities: [
      {
        id: '102',
        time: '08:00',
        title: 'Colazione in Hotel',
        description: 'Colazione inclusa nella mezza pensione',
        location: 'Paradise Sun Hotel',
        type: 'meal'
      },
      {
        id: '103',
        time: '09:30',
        title: 'Escursione Curieuse Island',
        description: 'Isola delle tartarughe giganti e mangrovie',
        location: 'Curieuse Island',
        type: 'exploration',
        duration: '6h',
        mapLink: 'https://maps.app.goo.gl/curieuse-island-seychelles'
      },
      {
        id: '104',
        time: '16:00',
        title: 'Rientro Hotel',
        description: 'Rientro dopo l\'escursione',
        location: 'Paradise Sun Hotel',
        type: 'activity'
      },
      {
        id: '105',
        time: '19:00',
        title: 'Cena in Hotel',
        description: 'Cena inclusa nella mezza pensione',
        location: 'Paradise Sun Hotel',
        type: 'meal'
      }
    ]
  },
  {
    date: '2025-07-16',
    dayName: 'Mercoledì',
    location: 'Seychelles - Praslin',
    weather: '🌴 31°C, Soleggiato',
    activities: [
      {
        id: '106',
        time: '08:00',
        title: 'Colazione in Hotel',
        description: 'Colazione inclusa nella mezza pensione',
        location: 'Paradise Sun Hotel',
        type: 'meal'
      },
      {
        id: '107',
        time: '10:00',
        title: 'Anse Georgette',
        description: 'Spiaggia privata accessibile dal Lemuria Resort',
        location: 'Anse Georgette, Praslin',
        type: 'activity',
        duration: '4h',
        mapLink: 'https://maps.app.goo.gl/anse-georgette-praslin'
      },
      {
        id: '108',
        time: '15:00',
        title: 'Shopping Souvenirs',
        description: 'Acquisto souvenir nel centro di Praslin',
        location: 'Grand Anse, Praslin',
        type: 'activity',
        duration: '2h',
        mapLink: 'https://maps.app.goo.gl/grand-anse-praslin-shops'
      },
      {
        id: '109',
        time: '19:00',
        title: 'Cena in Hotel',
        description: 'Cena inclusa nella mezza pensione',
        location: 'Paradise Sun Hotel',
        type: 'meal'
      }
    ]
  },
  {
    date: '2025-07-17',
    dayName: 'Giovedì',
    location: 'Seychelles - Praslin',
    weather: '🌴 28°C, Soleggiato',
    activities: [
      {
        id: '110',
        time: '08:00',
        title: 'Colazione in Hotel',
        description: 'Colazione inclusa nella mezza pensione',
        location: 'Paradise Sun Hotel',
        type: 'meal'
      },
      {
        id: '111',
        time: '10:00',
        title: 'Giornata Spa e Relax',
        description: 'Trattamenti spa e relax in piscina',
        location: 'Paradise Sun Hotel Spa',
        type: 'activity',
        duration: '6h',
        mapLink: 'https://maps.app.goo.gl/paradise-sun-hotel-spa'
      },
      {
        id: '112',
        time: '19:00',
        title: 'Cena Romantica',
        description: 'Cena romantica in spiaggia al tramonto',
        location: 'Paradise Sun Hotel Beach',
        type: 'meal',
        duration: '2h',
        mapLink: 'https://maps.app.goo.gl/paradise-sun-hotel-beach'
      }
    ]
  },
  {
    date: '2025-07-18',
    dayName: 'Venerdì',
    location: 'Seychelles - Praslin',
    weather: '🌴 30°C, Soleggiato',
    activities: [
      {
        id: '113',
        time: '08:00',
        title: 'Colazione in Hotel',
        description: 'Colazione inclusa nella mezza pensione',
        location: 'Paradise Sun Hotel',
        type: 'meal'
      },
      {
        id: '114',
        time: '09:30',
        title: 'Ultima Spiaggia',
        description: 'Ultima giornata in spiaggia alle Seychelles',
        location: 'Anse Volbert, Praslin',
        type: 'activity',
        duration: '6h',
        mapLink: 'https://maps.app.goo.gl/anse-volbert-praslin'
      },
      {
        id: '115',
        time: '16:00',
        title: 'Preparativi Partenza',
        description: 'Preparazione bagagli e ultimi acquisti',
        location: 'Paradise Sun Hotel',
        type: 'activity',
        duration: '2h'
      },
      {
        id: '116',
        time: '19:00',
        title: 'Cena d\'Addio',
        description: 'Ultima cena alle Seychelles',
        location: 'Paradise Sun Hotel',
        type: 'meal'
      }
    ]
  },
  {
    date: '2025-07-19',
    dayName: 'Sabato',
    location: 'Seychelles - Praslin',
    weather: '🌴 29°C, Soleggiato',
    activities: [
      {
        id: '117',
        time: '08:00',
        title: 'Colazione in Hotel',
        description: 'Ultima colazione alle Seychelles',
        location: 'Paradise Sun Hotel',
        type: 'meal'
      },
      {
        id: '118',
        time: '10:00',
        title: 'Relax Finale',
        description: 'Ultime ore di relax in paradiso',
        location: 'Paradise Sun Hotel',
        type: 'activity',
        duration: '4h'
      },
      {
        id: '119',
        time: '14:00',
        title: 'Check-out Hotel',
        description: 'Check-out e preparazione per la partenza',
        location: 'Paradise Sun Hotel',
        type: 'checkout'
      },
      {
        id: '120',
        time: '15:00',
        title: 'Trasferimento Aeroporto',
        description: 'Trasferimento all\'aeroporto di Mahé',
        location: 'Praslin → Aeroporto Mahé',
        type: 'transport',
        duration: '1h'
      },
      {
        id: '121',
        time: '16:30',
        title: 'Check-in Volo',
        description: 'Check-in per il volo di rientro',
        location: 'Aeroporto Seychelles',
        type: 'flight'
      }
    ]
  },
  {
    date: '2025-07-20',
    dayName: 'Domenica',
    location: 'Seychelles - Praslin',
    weather: '🌴 30°C, Soleggiato',
    activities: [
      {
        id: '122',
        time: '08:00',
        title: 'Ultima Colazione',
        description: 'Ultima colazione alle Seychelles',
        location: 'Paradise Sun Hotel',
        type: 'meal'
      },
      {
        id: '123',
        time: '10:00',
        title: 'Tempo Libero',
        description: 'Ultime ore di libertà in paradiso',
        location: 'Paradise Sun Hotel',
        type: 'activity',
        duration: '4h'
      },
      {
        id: '124',
        time: '14:00',
        title: 'Check-out Finale',
        description: 'Check-out definitivo dall\'hotel',
        location: 'Paradise Sun Hotel',
        type: 'checkout'
      },
      {
        id: '125',
        time: '15:00',
        title: 'Trasferimento Aeroporto',
        description: 'Ultimo trasferimento all\'aeroporto',
        location: 'Praslin → Aeroporto Mahé',
        type: 'transport',
        duration: '1h'
      }
    ]
  },
  {
    date: '2025-07-21',
    dayName: 'Lunedì',
    location: 'In Viaggio - Seychelles → Italia',
    weather: '✈️ Volo di Rientro',
    activities: [
      {
        id: '126',
        time: '17:20',
        title: 'Partenza dalle Seychelles',
        description: 'Volo ET 859 Mahé → Addis Abeba',
        location: 'Aeroporto Seychelles',
        type: 'flight',
        duration: '4h 45min',
        mapLink: 'https://maps.app.goo.gl/seychelles-international-airport'
      },
      {
        id: '127',
        time: '20:05',
        title: 'Arrivo ad Addis Abeba',
        description: 'Scalo tecnico ad Addis Abeba',
        location: 'Aeroporto Addis Abeba',
        type: 'flight',
        mapLink: 'https://maps.app.goo.gl/addis-ababa-airport'
      }
    ]
  },
  {
    date: '2025-07-22',
    dayName: 'Martedì',
    location: 'Milano, Italia',
    weather: '🏠 Ritorno a Casa',
    activities: [
      {
        id: '128',
        time: '00:15',
        title: 'Volo per Milano',
        description: 'Volo ET 706 Addis Abeba → Milano Malpensa',
        location: 'Addis Abeba → Milano',
        type: 'flight',
        duration: '7h 35min'
      },
      {
        id: '129',
        time: '05:50',
        title: 'Arrivo a Milano Malpensa',
        description: 'Atterraggio a Milano Malpensa - Fine del viaggio di nozze!',
        location: 'Aeroporto Milano Malpensa',
        type: 'flight',
        mapLink: 'https://maps.app.goo.gl/milano-malpensa-airport'
      },
      {
        id: '130',
        time: '07:00',
        title: 'Ritiro Bagagli',
        description: 'Ritiro bagagli e controlli doganali',
        location: 'Milano Malpensa',
        type: 'activity',
        duration: '1h'
      },
      {
        id: '131',
        time: '08:30',
        title: 'Rientro a Casa',
        description: 'Trasferimento verso casa - Fine del viaggio di nozze! 💕',
        location: 'Milano → Casa',
        type: 'transport',
        duration: '1h 30min'
      }
    ]
  }
];