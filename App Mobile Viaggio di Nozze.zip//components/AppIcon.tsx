import React from 'react';
import weddingImage from 'figma:asset/d192f9781d49221cdc39b70106e8642f93ee9bdb.png';

interface AppIconProps {
  size?: number;
  className?: string;
}

export default function AppIcon({ size = 40, className = "" }: AppIconProps) {
  return (
    <div 
      className={`rounded-full overflow-hidden shadow-lg flex-shrink-0 ${className}`}
      style={{ width: size, height: size }}
    >
      <img 
        src={weddingImage} 
        alt="27.06.25 - Alice & Alessandro"
        className="w-full h-full object-cover"
        style={{ objectPosition: 'center' }}
      />
    </div>
  );
}

// Function to generate and download icon files
export function generateAppIcons() {
  const canvas = document.createElement('canvas');
  const ctx = canvas.getContext('2d');
  const img = new Image();
  
  img.onload = function() {
    // Generate 192x192 icon
    canvas.width = 192;
    canvas.height = 192;
    ctx?.drawImage(img, 0, 0, 192, 192);
    
    canvas.toBlob((blob) => {
      if (blob) {
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = 'app-icon-192.png';
        a.click();
        URL.revokeObjectURL(url);
      }
    });
    
    // Generate 512x512 icon
    canvas.width = 512;
    canvas.height = 512;
    ctx?.drawImage(img, 0, 0, 512, 512);
    
    canvas.toBlob((blob) => {
      if (blob) {
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = 'app-icon-512.png';
        a.click();
        URL.revokeObjectURL(url);
      }
    });
  };
  
  img.src = weddingImage;
}