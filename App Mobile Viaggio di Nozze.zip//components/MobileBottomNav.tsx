import React from 'react';
import { Calendar, Map, Plane, Car, Settings, Plus } from 'lucide-react';
import { Button } from './ui/button';

interface MobileBottomNavProps {
  activeTab: string;
  onTabChange: (tab: string) => void;
  onAddActivity: () => void;
}

export default function MobileBottomNav({ activeTab, onTabChange, onAddActivity }: MobileBottomNavProps) {
  const tabs = [
    { id: 'calendar', icon: Calendar, label: 'Giornata' },
    { id: 'overview', icon: Map, label: 'Mappa' },
    { id: 'flights', icon: Plane, label: 'Voli' },
    { id: 'cars', icon: Car, label: 'Auto' }
  ];

  return (
    <>
      {/* Floating Action Button */}
      <div className="fixed bottom-20 right-4 z-50">
        <Button
          onClick={onAddActivity}
          size="lg"
          className="w-14 h-14 rounded-full bg-gradient-to-r from-pink-500 to-rose-500 hover:from-pink-600 hover:to-rose-600 shadow-lg"
        >
          <Plus className="w-6 h-6" />
        </Button>
      </div>

      {/* Bottom Navigation */}
      <div className="fixed bottom-0 left-0 right-0 bg-white/95 backdrop-blur-sm border-t border-gray-200 z-40">
        <div className="safe-area-padding-bottom">
          <div className="flex items-center justify-around px-2 py-2">
            {tabs.map((tab) => {
              const Icon = tab.icon;
              const isActive = activeTab === tab.id;
              
              return (
                <button
                  key={tab.id}
                  onClick={() => onTabChange(tab.id)}
                  className={`flex flex-col items-center justify-center p-2 rounded-lg transition-all duration-200 min-w-[60px] ${
                    isActive 
                      ? 'text-pink-600 bg-pink-50' 
                      : 'text-gray-500 hover:text-gray-700 hover:bg-gray-50'
                  }`}
                >
                  <Icon className={`w-5 h-5 mb-1 ${isActive ? 'text-pink-600' : 'text-gray-500'}`} />
                  <span className={`text-xs ${isActive ? 'text-pink-600 font-medium' : 'text-gray-500'}`}>
                    {tab.label}
                  </span>
                  {isActive && (
                    <div className="w-4 h-0.5 bg-pink-600 rounded-full mt-1" />
                  )}
                </button>
              );
            })}
          </div>
        </div>
      </div>
    </>
  );
}