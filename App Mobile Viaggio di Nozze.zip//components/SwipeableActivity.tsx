import React from 'react';
import { MoreHorizontal, Edit, Trash2, MapPin, ExternalLink } from 'lucide-react';
import { Card, CardContent } from './ui/card';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from './ui/dropdown-menu';
import { Activity } from '../data/itinerary';

interface SwipeableActivityProps {
  activity: Activity;
  isCurrentActivity: boolean;
  isPastActivity: boolean;
  onEdit: () => void;
  onDelete?: () => void;
  getTypeIcon: (type: string) => React.ReactNode;
  getTypeColor: (type: string) => string;
}

export default function SwipeableActivity({
  activity,
  isCurrentActivity,
  isPastActivity,
  onEdit,
  onDelete,
  getTypeIcon,
  getTypeColor
}: SwipeableActivityProps) {
  
  const handleMapClick = () => {
    if (activity.mapLink) {
      window.open(activity.mapLink, '_blank');
    } else if (activity.location) {
      // Fallback to Google Maps search
      const query = encodeURIComponent(activity.location);
      window.open(`https://maps.google.com/maps?q=${query}`, '_blank');
    }
  };

  return (
    <Card className={`
      relative transition-all duration-200 hover:shadow-md h-[160px] activity-card
      ${isCurrentActivity ? 'ring-2 ring-pink-400 bg-pink-50 activity-card-current' : ''}
      ${isPastActivity ? 'opacity-75' : ''}
      ${activity.isPlaceholder ? 'border-dashed border-indigo-300 bg-indigo-50/50' : ''}
    `}>
      <CardContent className="p-4 h-full flex flex-col">
        <div className="flex items-start justify-between gap-2 mb-3">
          <div className="flex items-center gap-2 min-w-0">
            <div className="flex items-center gap-2">
              <span className={`text-sm font-medium px-2 py-1 rounded-full flex items-center ${getTypeColor(activity.type)}`}>
                {getTypeIcon(activity.type)}
              </span>
              <span className="text-base font-medium text-gray-700">{activity.time}</span>
              {activity.duration && (
                <Badge variant="outline" className="text-xs px-2 py-1 h-5">
                  {activity.duration}
                </Badge>
              )}
            </div>
          </div>
          
          <div className="flex items-center gap-1">
            {isCurrentActivity && (
              <Badge className="bg-pink-500 text-white animate-pulse text-xs px-2 py-1 h-6">
                In corso
              </Badge>
            )}
            {activity.isPlaceholder && (
              <Badge variant="outline" className="text-indigo-600 border-indigo-300 text-xs px-2 py-1 h-6">
                Da esplorare
              </Badge>
            )}
            
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button 
                  variant="ghost" 
                  size="sm" 
                  className="h-7 w-7 p-0 hover:bg-gray-100"
                >
                  <MoreHorizontal className="w-4 h-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-40">
                <DropdownMenuItem onClick={onEdit} className="gap-2 text-sm">
                  <Edit className="w-4 h-4" />
                  Modifica
                </DropdownMenuItem>
                {(activity.mapLink || activity.location) && (
                  <DropdownMenuItem onClick={handleMapClick} className="gap-2 text-sm">
                    <ExternalLink className="w-4 h-4" />
                    Mappa
                  </DropdownMenuItem>
                )}
                {onDelete && (
                  <DropdownMenuItem 
                    onClick={onDelete} 
                    className="gap-2 text-sm text-red-600 focus:text-red-600"
                  >
                    <Trash2 className="w-4 h-4" />
                    {(activity as any).isUserCreated ? 'Elimina' : 'Nascondi'}
                  </DropdownMenuItem>
                )}
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>
        
        <div className="flex-1 min-h-0">
          <h3 className="font-semibold text-gray-900 text-base line-clamp-2 mb-2">
            {activity.title}
          </h3>
          
          {activity.description && (
            <p className="text-gray-600 text-sm line-clamp-2 mb-3">
              {activity.description}
            </p>
          )}
          
          {activity.location && (
            <div className="flex items-center gap-2 mb-2">
              <MapPin className="w-4 h-4 text-gray-400 flex-shrink-0" />
              <span className="text-sm text-gray-600 line-clamp-1 flex-1">
                {activity.location}
              </span>
              {(activity.mapLink || activity.location) && (
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={handleMapClick}
                  className="h-6 px-2 text-blue-600 hover:text-blue-800 hover:bg-blue-50 text-xs"
                >
                  <ExternalLink className="w-3 h-3 mr-1" />
                  Mappa
                </Button>
              )}
            </div>
          )}
        </div>
        
        <div className="mt-auto">
          {activity.userNotes && (
            <div className="p-2 bg-yellow-50 border border-yellow-200 rounded text-sm mb-2">
              <p className="text-yellow-800 line-clamp-2">📝 {activity.userNotes}</p>
            </div>
          )}
          
          {activity.notes && (
            <div className="p-2 bg-gray-50 border border-gray-200 rounded text-sm">
              <p className="text-gray-700 line-clamp-2">{activity.notes}</p>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}