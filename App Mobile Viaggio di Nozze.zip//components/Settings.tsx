import React, { useState, useEffect } from 'react';
import { 
  Settings as SettingsIcon, 
  LogOut, 
  Download, 
  Smartphone, 
  Wifi, 
  WifiOff, 
  RefreshCw, 
  Trash2, 
  Info, 
  CheckCircle, 
  AlertCircle, 
  Heart, 
  ExternalLink,
  Calendar,
  MapPin,
  Plane,
  Shield,
  Zap,
  Clock,
  Database,
  Globe,
  Wrench,
  HelpCircle
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Separator } from './ui/separator';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from './ui/dialog';
import { toast } from 'sonner@2.0.3';
import { useServiceWorker } from '../hooks/useServiceWorker';
import AppIcon from './AppIcon';
import ServiceWorkerSetup from './ServiceWorkerSetup';

interface SettingsProps {
  onLogout: () => void;
  hasChanges: boolean;
  currentTime: Date;
}

export default function Settings({ onLogout, hasChanges, currentTime }: SettingsProps) {
  const { 
    isSupported,
    isRegistered,
    updateAvailable, 
    isInstallable,
    isOnline,
    isAppInstalled,
    registrationError,
    swVersion,
    installApp,
    applyUpdate,
    clearCache,
    getSwVersion
  } = useServiceWorker();

  const [isClearing, setIsClearing] = useState(false);
  const [cacheSize, setCacheSize] = useState<string>('Sconosciuto');
  const [appVersion, setAppVersion] = useState('1.1.0');
  const [showDiagnostics, setShowDiagnostics] = useState(false);

  // Get cache size estimate
  useEffect(() => {
    const estimateCacheSize = async () => {
      if ('storage' in navigator && 'estimate' in navigator.storage) {
        try {
          const estimate = await navigator.storage.estimate();
          const usage = estimate.usage || 0;
          const quota = estimate.quota || 0;
          
          const formatBytes = (bytes: number) => {
            if (bytes === 0) return '0 Bytes';
            const k = 1024;
            const sizes = ['Bytes', 'KB', 'MB', 'GB'];
            const i = Math.floor(Math.log(bytes) / Math.log(k));
            return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
          };

          setCacheSize(`${formatBytes(usage)} / ${formatBytes(quota)}`);
        } catch (error) {
          console.warn('Could not estimate storage:', error);
        }
      }
    };

    estimateCacheSize();
  }, []);

  // Manual install instructions
  const handleManualInstall = () => {
    const isIOS = /iPad|iPhone|iPod/.test(navigator.userAgent);
    const isSafari = /^((?!chrome|android).)*safari/i.test(navigator.userAgent);
    
    if (isIOS && isSafari) {
      toast(
        <div className="space-y-2">
          <p className="font-medium">📱 Per installare su iPhone:</p>
          <ol className="text-sm space-y-1 list-decimal list-inside">
            <li>Tocca l'icona "Condividi" ⬆️ in basso</li>
            <li>Scorri e trova "Aggiungi alla schermata Home"</li>
            <li>Tocca "Aggiungi" per confermare</li>
          </ol>
        </div>,
        { duration: 8000 }
      );
    } else {
      toast(
        <div className="space-y-2">
          <p className="font-medium">📱 Per installare l'app:</p>
          <p className="text-sm">Cerca il menu del browser e seleziona "Installa app" o "Aggiungi alla schermata home"</p>
        </div>,
        { duration: 6000 }
      );
    }
  };

  const handleClearCache = async () => {
    setIsClearing(true);
    try {
      await clearCache();
      toast.success('Cache pulita con successo! 🧹');
      // Refresh cache size
      setTimeout(() => {
        window.location.reload();
      }, 1000);
    } catch (error) {
      toast.error('Errore durante la pulizia della cache');
    } finally {
      setIsClearing(false);
    }
  };

  const handleLogout = () => {
    onLogout();
    toast.info('Logout effettuato! Alla prossima! 👋');
  };

  // Check if we're in a preview environment
  const isFigmaPreview = window.location.hostname.includes('figma.site');

  return (
    <div className="space-y-6">
      {/* App Info Header */}
      <Card className="border-2 border-gradient-to-r from-pink-200 to-blue-200">
        <CardHeader className="pb-4">
          <div className="flex items-center gap-4">
            <AppIcon size={48} />
            <div className="flex-1">
              <CardTitle className="flex items-center gap-2">
                27.06.25
                <Badge variant="outline" className="bg-pink-50 text-pink-700 border-pink-200">
                  v{appVersion}
                </Badge>
              </CardTitle>
              <p className="text-gray-600 mt-1">Alice & Alessandro • Il nostro matrimonio e viaggio di nozze</p>
              <p className="text-sm text-gray-500 mt-2">
                📅 27 Giugno - 22 Luglio 2025 • 🌍 Milano → Sudafrica → Seychelles
              </p>
            </div>
          </div>
        </CardHeader>
      </Card>

      {/* PWA Setup Help - Show if there are issues */}
      {(!isRegistered || !isSupported || registrationError) && (
        <Card className="border-orange-200 bg-orange-50">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-orange-800">
              <HelpCircle className="w-5 h-5" />
              Service Worker - Setup Richiesto
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-orange-700 mb-4">
              Il Service Worker non è attivo. Questo significa che alcune funzionalità PWA potrebbero non funzionare.
            </p>
            <div className="space-y-2 mb-4">
              {!isSupported && (
                <div className="flex items-center gap-2 text-sm text-orange-700">
                  <AlertCircle className="w-4 h-4" />
                  <span>Service Workers non supportati dal browser</span>
                </div>
              )}
              {!isRegistered && isSupported && (
                <div className="flex items-center gap-2 text-sm text-orange-700">
                  <AlertCircle className="w-4 h-4" />
                  <span>Service Worker non registrato</span>
                </div>
              )}
              {registrationError && (
                <div className="flex items-center gap-2 text-sm text-orange-700">
                  <AlertCircle className="w-4 h-4" />
                  <span>{registrationError}</span>
                </div>
              )}
            </div>
            <Button 
              onClick={() => setShowDiagnostics(true)}
              className="bg-orange-600 hover:bg-orange-700"
            >
              <Wrench className="w-4 h-4 mr-2" />
              Avvia Diagnostica e Setup
            </Button>
          </CardContent>
        </Card>
      )}

      {/* PWA Status */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2">
              <Smartphone className="w-5 h-5" />
              Stato App Progressiva (PWA)
            </CardTitle>
            <Button
              onClick={() => setShowDiagnostics(true)}
              variant="ghost"
              size="sm"
            >
              <Wrench className="w-4 h-4 mr-2" />
              Diagnostica
            </Button>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Connection Status */}
          <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
            <div className="flex items-center gap-3">
              {isOnline ? <Wifi className="w-4 h-4 text-green-600" /> : <WifiOff className="w-4 h-4 text-orange-600" />}
              <span className="font-medium">Stato Connessione</span>
            </div>
            <Badge variant={isOnline ? "default" : "secondary"} className={isOnline ? "bg-green-100 text-green-700" : "bg-orange-100 text-orange-700"}>
              {isOnline ? '🟢 Online' : '🔴 Offline'}
            </Badge>
          </div>

          {/* Service Worker Status */}
          <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
            <div className="flex items-center gap-3">
              <Shield className="w-4 h-4 text-blue-600" />
              <span className="font-medium">Service Worker</span>
            </div>
            <div className="flex items-center gap-2">
              {isRegistered ? (
                <Badge className="bg-green-100 text-green-700">
                  ✅ Attivo
                </Badge>
              ) : (
                <Badge variant="secondary" className="bg-orange-100 text-orange-700">
                  ⚠️ Non attivo
                </Badge>
              )}
              {swVersion && (
                <Badge variant="outline" className="text-xs">
                  {swVersion}
                </Badge>
              )}
            </div>
          </div>

          {/* Installation Status */}
          <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
            <div className="flex items-center gap-3">
              <Download className="w-4 h-4 text-purple-600" />
              <span className="font-medium">Installazione</span>
            </div>
            <Badge variant={isAppInstalled ? "default" : "secondary"} className={isAppInstalled ? "bg-green-100 text-green-700" : "bg-blue-100 text-blue-700"}>
              {isAppInstalled ? '📱 Installata' : '🌐 Browser'}
            </Badge>
          </div>

          {/* Storage Usage */}
          <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
            <div className="flex items-center gap-3">
              <Database className="w-4 h-4 text-indigo-600" />
              <span className="font-medium">Spazio Cache</span>
            </div>
            <Badge variant="outline">
              {cacheSize}
            </Badge>
          </div>

          {/* Error Display */}
          {registrationError && (
            <div className="p-3 bg-orange-50 border border-orange-200 rounded-lg">
              <div className="flex items-start gap-2">
                <AlertCircle className="w-4 h-4 text-orange-600 mt-0.5 flex-shrink-0" />
                <div>
                  <p className="text-sm font-medium text-orange-800">Avviso Service Worker</p>
                  <p className="text-xs text-orange-700 mt-1">{registrationError}</p>
                </div>
              </div>
            </div>
          )}

          {/* Preview Environment Notice */}
          {isFigmaPreview && (
            <div className="p-3 bg-blue-50 border border-blue-200 rounded-lg">
              <div className="flex items-start gap-2">
                <Info className="w-4 h-4 text-blue-600 mt-0.5 flex-shrink-0" />
                <div>
                  <p className="text-sm font-medium text-blue-800">Modalità Preview Figma</p>
                  <p className="text-xs text-blue-700 mt-1">
                    L'app funziona completamente, alcune funzionalità PWA sono limitate in modalità preview.
                  </p>
                </div>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* PWA Actions */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Zap className="w-5 h-5" />
            Azioni App
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          {/* Install App */}
          {!isAppInstalled && (
            <div className="p-4 bg-gradient-to-r from-pink-50 to-blue-50 border border-pink-200 rounded-lg">
              <div className="flex items-center justify-between mb-3">
                <div>
                  <h4 className="font-medium text-pink-800">💕 Installa l'App</h4>
                  <p className="text-sm text-pink-700">Accesso rapido durante il viaggio</p>
                </div>
                <Download className="w-5 h-5 text-pink-600" />
              </div>
              <div className="flex gap-2">
                {isInstallable ? (
                  <Button onClick={installApp} className="bg-pink-600 hover:bg-pink-700" size="sm">
                    <Download className="w-4 h-4 mr-2" />
                    Installa Ora
                  </Button>
                ) : (
                  <Button onClick={handleManualInstall} variant="outline" size="sm">
                    <Smartphone className="w-4 h-4 mr-2" />
                    Istruzioni
                  </Button>
                )}
              </div>
            </div>
          )}

          {/* Update Available */}
          {updateAvailable && (
            <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
              <div className="flex items-center justify-between mb-3">
                <div>
                  <h4 className="font-medium text-blue-800">🔄 Aggiornamento Disponibile</h4>
                  <p className="text-sm text-blue-700">Nuova versione dell'app pronta</p>
                </div>
                <RefreshCw className="w-5 h-5 text-blue-600" />
              </div>
              <Button onClick={applyUpdate} className="bg-blue-600 hover:bg-blue-700" size="sm">
                <RefreshCw className="w-4 h-4 mr-2" />
                Aggiorna Ora
              </Button>
            </div>
          )}

          {/* Unsaved Changes */}
          {hasChanges && (
            <div className="p-4 bg-orange-50 border border-orange-200 rounded-lg">
              <div className="flex items-center gap-2 mb-2">
                <AlertCircle className="w-4 h-4 text-orange-600" />
                <h4 className="font-medium text-orange-800">Modifiche Non Salvate</h4>
              </div>
              <p className="text-sm text-orange-700">
                Hai delle modifiche all'itinerario che non sono state sincronizzate.
              </p>
            </div>
          )}

          {/* Service Worker Actions */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
              <div>
                <span className="font-medium text-sm">Diagnostica</span>
                <p className="text-xs text-gray-600">Verifica configurazione PWA</p>
              </div>
              <Button 
                onClick={() => setShowDiagnostics(true)}
                variant="outline" 
                size="sm"
              >
                <Wrench className="w-4 h-4 mr-2" />
                Avvia
              </Button>
            </div>

            <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
              <div>
                <span className="font-medium text-sm">Pulisci Cache</span>
                <p className="text-xs text-gray-600">Libera spazio e risolvi problemi</p>
              </div>
              <Button 
                onClick={handleClearCache} 
                disabled={isClearing}
                variant="outline" 
                size="sm"
              >
                {isClearing ? (
                  <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                ) : (
                  <Trash2 className="w-4 h-4 mr-2" />
                )}
                {isClearing ? 'Pulizia...' : 'Pulisci'}
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* App Information */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Info className="w-5 h-5" />
            Informazioni Viaggio
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg">
              <Calendar className="w-4 h-4 text-blue-600" />
              <div>
                <p className="font-medium">Durata</p>
                <p className="text-sm text-gray-600">25 giorni</p>
              </div>
            </div>
            
            <div className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg">
              <MapPin className="w-4 h-4 text-green-600" />
              <div>
                <p className="font-medium">Destinazioni</p>
                <p className="text-sm text-gray-600">3 paesi</p>
              </div>
            </div>
            
            <div className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg">
              <Plane className="w-4 h-4 text-purple-600" />
              <div>
                <p className="font-medium">Voli</p>
                <p className="text-sm text-gray-600">6 tratte</p>
              </div>
            </div>
            
            <div className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg">
              <Heart className="w-4 h-4 text-pink-600" />
              <div>
                <p className="font-medium">Matrimonio</p>
                <p className="text-sm text-gray-600">27 Giugno 2025</p>
              </div>
            </div>
          </div>

          <Separator />

          <div className="space-y-2">
            <h4 className="font-medium">Itinerario Completo</h4>
            <div className="text-sm text-gray-600 space-y-1">
              <p>🇮🇹 <strong>Milano</strong> - Matrimonio e partenza</p>
              <p>🇿🇦 <strong>Cape Town</strong> - Città del Capo e dintorni</p>
              <p>🇿🇦 <strong>Kruger National Park</strong> - Safari e natura</p>
              <p>🇸🇨 <strong>Seychelles</strong> - Mahé, Praslin e La Digue</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* App Features */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <CheckCircle className="w-5 h-5" />
            Funzionalità App
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div className="flex items-center gap-2 text-sm">
              <CheckCircle className="w-3 h-3 text-green-600" />
              <span>Timeline interattiva</span>
            </div>
            <div className="flex items-center gap-2 text-sm">
              <CheckCircle className="w-3 h-3 text-green-600" />
              <span>Funzionalità offline</span>
            </div>
            <div className="flex items-center gap-2 text-sm">
              <CheckCircle className="w-3 h-3 text-green-600" />
              <span>Calendario scorrevole</span>
            </div>
            <div className="flex items-center gap-2 text-sm">
              <CheckCircle className="w-3 h-3 text-green-600" />
              <span>Aggiunta attività personalizzate</span>
            </div>
            <div className="flex items-center gap-2 text-sm">
              <CheckCircle className="w-3 h-3 text-green-600" />  
              <span>Informazioni voli e hotel</span>
            </div>
            <div className="flex items-center gap-2 text-sm">
              <CheckCircle className="w-3 h-3 text-green-600" />
              <span>Mappe integrate Google</span>
            </div>
            <div className="flex items-center gap-2 text-sm">
              <CheckCircle className="w-3 h-3 text-green-600" />
              <span>Aggiornamenti automatici</span>
            </div>
            <div className="flex items-center gap-2 text-sm">
              <CheckCircle className="w-3 h-3 text-green-600" />
              <span>Responsive design</span>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* System Information */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Globe className="w-5 h-5" />
            Informazioni Tecniche
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="grid grid-cols-2 gap-4 text-sm">
            <div>
              <span className="text-gray-600">Browser:</span>
              <p className="font-mono">{navigator.userAgent.split(' ').pop()}</p>
            </div>
            <div>
              <span className="text-gray-600">PWA Support:</span>
              <p>{isSupported ? '✅ Supportato' : '❌ Non supportato'}</p>
            </div>
            <div>
              <span className="text-gray-600">Ultima sincronizzazione:</span>
              <p>{currentTime.toLocaleTimeString('it-IT')}</p>
            </div>
            <div>
              <span className="text-gray-600">Ambiente:</span>
              <p>{isFigmaPreview ? '🔍 Preview' : '🚀 Produzione'}</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Logout Section */}
      <Card className="border-red-200">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-red-700">
            <LogOut className="w-5 h-5" />
            Esci dall'App
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-gray-600 mb-4">
            Effettua il logout per uscire dall'app. Dovrai inserire nuovamente le credenziali per accedere.
          </p>
          <Button 
            onClick={handleLogout} 
            variant="destructive" 
            className="w-full sm:w-auto"
          >
            <LogOut className="w-4 h-4 mr-2" />
            Logout
          </Button>
        </CardContent>
      </Card>

      {/* Footer Info */}
      <div className="text-center py-6 text-sm text-gray-500">
        <p>💕 Creato con amore per Alice & Alessandro</p>
        <p className="mt-1">Viaggio di nozze • Giugno - Luglio 2025</p>
      </div>

      {/* Service Worker Diagnostics Dialog */}
      <Dialog open={showDiagnostics} onOpenChange={setShowDiagnostics}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Diagnostica Service Worker</DialogTitle>
          </DialogHeader>
          <ServiceWorkerSetup onClose={() => setShowDiagnostics(false)} />
        </DialogContent>
      </Dialog>
    </div>
  );
}