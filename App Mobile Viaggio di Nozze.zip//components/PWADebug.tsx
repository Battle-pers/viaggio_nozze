import React, { useState } from 'react';
import { Settings, Trash2, Download, RefreshCw, Wifi, WifiOff, Smartphone, Image as ImageIcon, AlertTriangle, Info } from 'lucide-react';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Alert, AlertDescription } from './ui/alert';
import { useServiceWorker } from '../hooks/useServiceWorker';
import { generateAppIcons } from './AppIcon';
import { toast } from 'sonner@2.0.3';

export default function PWADebug() {
  const [isOpen, setIsOpen] = useState(false);
  const { 
    isSupported, 
    isRegistered, 
    updateAvailable, 
    isInstallable,
    applyUpdate,
    clearCache,
    installApp,
    isOnline,
    isAppInstalled,
    registration,
    registrationError
  } = useServiceWorker();

  const handleClearCache = async () => {
    await clearCache();
    toast.success('Cache pulita! Ricarica la pagina per vedere i cambiamenti.');
  };

  const handleForceUpdate = () => {
    if ('serviceWorker' in navigator && navigator.serviceWorker.controller) {
      navigator.serviceWorker.controller.postMessage({ type: 'SKIP_WAITING' });
      window.location.reload();
    } else {
      window.location.reload();
    }
  };

  const handleGenerateIcons = () => {
    generateAppIcons();
    toast.success('Icone generate! Controlla i download.');
  };

  const getInstallationStatus = () => {
    if (isAppInstalled) return 'Installata';
    if (isInstallable) return 'Installabile';
    return 'Non installabile';
  };

  const getConnectionInfo = () => {
    if ('connection' in navigator) {
      const conn = (navigator as any).connection;
      return `${conn.effectiveType || 'unknown'} (${conn.downlink || 'unknown'} Mbps)`;
    }
    return 'Info non disponibili';
  };

  const getEnvironmentInfo = () => {
    const isLocalhost = window.location.hostname === 'localhost' || window.location.hostname === '127.0.0.1';
    const isHTTPS = window.location.protocol === 'https:';
    const isFigmaPreview = window.location.hostname.includes('figma.site');
    
    return { isLocalhost, isHTTPS, isFigmaPreview };
  };

  const { isLocalhost, isHTTPS, isFigmaPreview } = getEnvironmentInfo();

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>
        <Button 
          variant="ghost" 
          size="sm" 
          className="fixed bottom-4 right-4 z-50 opacity-30 hover:opacity-100 transition-opacity"
          title="PWA Debug"
        >
          <Settings className="w-4 h-4" />
        </Button>
      </DialogTrigger>
      
      <DialogContent className="max-w-md max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Smartphone className="w-5 h-5" />
            PWA Debug - 27.06.25
          </DialogTitle>
        </DialogHeader>
        
        <Tabs defaultValue="status" className="w-full">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="status">Status</TabsTrigger>
            <TabsTrigger value="tools">Tools</TabsTrigger>
          </TabsList>
          
          <TabsContent value="status" className="space-y-4 mt-4">
            {/* Environment Info */}
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-sm flex items-center gap-2">
                  <Info className="w-4 h-4" />
                  Ambiente
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <div className="flex justify-between items-center">
                  <span className="text-sm text-gray-600">Localhost:</span>
                  <Badge variant={isLocalhost ? 'default' : 'outline'}>
                    {isLocalhost ? 'Sì' : 'No'}
                  </Badge>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-gray-600">HTTPS:</span>
                  <Badge variant={isHTTPS ? 'default' : 'destructive'}>
                    {isHTTPS ? 'Sì' : 'No'}
                  </Badge>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-gray-600">Figma Preview:</span>
                  <Badge variant={isFigmaPreview ? 'secondary' : 'outline'}>
                    {isFigmaPreview ? 'Sì' : 'No'}
                  </Badge>
                </div>
              </CardContent>
            </Card>

            {/* Service Worker Errors */}
            {registrationError && (
              <Alert className="border-orange-200 bg-orange-50">
                <AlertTriangle className="h-4 w-4 text-orange-600" />
                <AlertDescription className="text-sm text-orange-800">
                  <strong>Service Worker Error:</strong><br />
                  {registrationError}
                  {isFigmaPreview && (
                    <div className="mt-2 text-xs">
                      <em>Nota: I Service Workers potrebbero non funzionare nelle preview di Figma. L'app funziona comunque normalmente.</em>
                    </div>
                  )}
                </AlertDescription>
              </Alert>
            )}

            {/* Service Worker Status */}
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-sm">Service Worker</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <div className="flex justify-between items-center">
                  <span className="text-sm text-gray-600">Supportato:</span>
                  <Badge variant={isSupported ? 'default' : 'destructive'}>
                    {isSupported ? 'Sì' : 'No'}
                  </Badge>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-gray-600">Registrato:</span>
                  <Badge variant={isRegistered ? 'default' : 'destructive'}>
                    {isRegistered ? 'Sì' : 'No'}
                  </Badge>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-gray-600">Aggiornamento:</span>
                  <Badge variant={updateAvailable ? 'destructive' : 'default'}>
                    {updateAvailable ? 'Disponibile' : 'Aggiornato'}
                  </Badge>
                </div>
              </CardContent>
            </Card>

            {/* Installation Status */}
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-sm">Installazione</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <div className="flex justify-between items-center">
                  <span className="text-sm text-gray-600">Status:</span>
                  <Badge variant={isAppInstalled ? 'default' : isInstallable ? 'secondary' : 'outline'}>
                    {getInstallationStatus()}
                  </Badge>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-gray-600">Display Mode:</span>
                  <Badge variant="outline">
                    {window.matchMedia('(display-mode: standalone)').matches ? 'Standalone' : 'Browser'}
                  </Badge>
                </div>
                {!isInstallable && !isAppInstalled && (
                  <div className="text-xs text-gray-500 mt-2">
                    <p>Per installare l'app:</p>
                    <ul className="list-disc ml-4 mt-1">
                      <li>Usa HTTPS o localhost</li>
                      <li>Aggiungi alla home screen</li>
                      <li>Usa un browser supportato</li>
                    </ul>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Connection Status */}
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-sm flex items-center gap-2">
                  {isOnline ? <Wifi className="w-4 h-4 text-green-600" /> : <WifiOff className="w-4 h-4 text-red-600" />}
                  Connessione
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <div className="flex justify-between items-center">
                  <span className="text-sm text-gray-600">Stato:</span>
                  <Badge variant={isOnline ? 'default' : 'destructive'}>
                    {isOnline ? 'Online' : 'Offline'}
                  </Badge>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-gray-600">Info:</span>
                  <span className="text-xs text-gray-500">{getConnectionInfo()}</span>
                </div>
              </CardContent>
            </Card>

            {/* Technical Info */}
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-sm">Info Tecniche</CardTitle>
              </CardHeader>
              <CardContent className="space-y-1">
                <div className="text-xs space-y-1">
                  <div><strong>User Agent:</strong> {navigator.userAgent.split(' ').slice(-2).join(' ')}</div>
                  <div><strong>Viewport:</strong> {window.innerWidth}x{window.innerHeight}</div>
                  <div><strong>Registration:</strong> {registration ? '✅' : '❌'}</div>
                  <div><strong>Cache API:</strong> {'caches' in window ? '✅' : '❌'}</div>
                  <div><strong>Storage:</strong> {navigator.storage ? '✅' : '❌'}</div>
                  <div><strong>Manifest:</strong> {document.querySelector('link[rel="manifest"]') ? '✅' : '❌'}</div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="tools" className="space-y-4 mt-4">
            {/* PWA Actions */}
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-sm">Azioni PWA</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                {/* Install App */}
                {isInstallable && !isAppInstalled && (
                  <Button onClick={installApp} className="w-full gap-2" size="sm">
                    <Download className="w-4 h-4" />
                    Installa App
                  </Button>
                )}

                {/* Apply Update */}
                {updateAvailable && (
                  <Button onClick={applyUpdate} className="w-full gap-2" size="sm" variant="outline">
                    <RefreshCw className="w-4 h-4" />
                    Applica Aggiornamento
                  </Button>
                )}

                {/* Clear Cache */}
                <Button onClick={handleClearCache} className="w-full gap-2" size="sm" variant="outline">
                  <Trash2 className="w-4 h-4" />
                  Pulisci Cache
                </Button>

                {/* Force Reload */}
                <Button onClick={handleForceUpdate} className="w-full gap-2" size="sm" variant="outline">
                  <RefreshCw className="w-4 h-4" />
                  Ricarica Forzata
                </Button>
              </CardContent>
            </Card>

            {/* Icon Generator */}
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-sm">Generatore Icone</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <p className="text-xs text-gray-600 mb-2">
                  Genera icone app dalle dimensioni corrette dalla foto del matrimonio.
                </p>
                <Button onClick={handleGenerateIcons} className="w-full gap-2" size="sm" variant="outline">
                  <ImageIcon className="w-4 h-4" />
                  Genera Icone App
                </Button>
                <div className="text-xs text-gray-500 mt-2">
                  <p>Saranno generati: app-icon-192.png e app-icon-512.png</p>
                </div>
              </CardContent>
            </Card>

            {/* Troubleshooting */}
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-sm">Risoluzione Problemi</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <div className="text-xs text-gray-600 space-y-2">
                  <div><strong>Service Worker non funziona?</strong></div>
                  <ul className="list-disc ml-4 space-y-1">
                    <li>Verifica che sia HTTPS o localhost</li>
                    <li>Controlla la console per errori</li>
                    <li>Prova a pulire la cache</li>
                    <li>In Figma Preview è normale che non funzioni</li>
                  </ul>
                  
                  <div className="mt-3"><strong>App non installabile?</strong></div>
                  <ul className="list-disc ml-4 space-y-1">
                    <li>Usa Chrome, Edge o Safari</li>
                    <li>Visita il sito più volte</li>
                    <li>Aggiungi manualmente alla home screen</li>
                  </ul>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}