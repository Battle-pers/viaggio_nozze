import React, { useState, useEffect } from 'react';
import { 
  CheckCircle, 
  XCircle, 
  AlertTriangle, 
  Info, 
  RefreshCw, 
  Globe, 
  Shield, 
  Smartphone,
  Terminal,
  Copy,
  ExternalLink,
  Settings,
  Wrench
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Separator } from './ui/separator';
import { toast } from 'sonner@2.0.3';

interface ServiceWorkerSetupProps {
  onClose?: () => void;
}

interface DiagnosticResult {
  name: string;
  status: 'success' | 'warning' | 'error' | 'info';
  message: string;
  details?: string;
  action?: string;
}

export default function ServiceWorkerSetup({ onClose }: ServiceWorkerSetupProps) {
  const [diagnostics, setDiagnostics] = useState<DiagnosticResult[]>([]);
  const [isRunning, setIsRunning] = useState(false);
  const [showDetails, setShowDetails] = useState(false);

  const runDiagnostics = async () => {
    setIsRunning(true);
    const results: DiagnosticResult[] = [];

    // 1. Check Service Worker Support
    if ('serviceWorker' in navigator) {
      results.push({
        name: 'Service Worker Support',
        status: 'success',
        message: 'Service Workers sono supportati',
        details: 'Il browser supporta completamente i Service Workers'
      });
    } else {
      results.push({
        name: 'Service Worker Support',
        status: 'error',
        message: 'Service Workers NON supportati',
        details: 'Il browser non supporta i Service Workers. Prova con Chrome, Firefox, Safari o Edge moderni.',
        action: 'Aggiorna il browser o usa un browser moderno'
      });
    }

    // 2. Check HTTPS/Localhost
    const isHTTPS = window.location.protocol === 'https:';
    const isLocalhost = window.location.hostname === 'localhost' || 
                       window.location.hostname === '127.0.0.1' ||
                       window.location.hostname === '';
    const isFigma = window.location.hostname.includes('figma.site');

    if (isHTTPS || isLocalhost) {
      results.push({
        name: 'Secure Context',
        status: 'success',
        message: 'Ambiente sicuro (HTTPS o localhost)',
        details: `Protocollo: ${window.location.protocol}, Host: ${window.location.hostname}`
      });
    } else {
      results.push({
        name: 'Secure Context',
        status: 'error',
        message: 'Serve HTTPS o localhost',
        details: 'I Service Workers funzionano solo su HTTPS o localhost per motivi di sicurezza',
        action: 'Usa HTTPS o testa su localhost'
      });
    }

    // 3. Check if in Figma Preview
    if (isFigma) {
      results.push({
        name: 'Ambiente Figma',
        status: 'warning',
        message: 'Modalità Preview Figma rilevata',
        details: 'Alcune funzionalità PWA potrebbero essere limitate in modalità preview',
        action: 'Testa l\'app in un ambiente di produzione per funzionalità complete'
      });
    }

    // 4. Check Service Worker file
    try {
      const swResponse = await fetch('/sw.js', { method: 'HEAD' });
      if (swResponse.ok) {
        results.push({
          name: 'File Service Worker',
          status: 'success',
          message: 'File sw.js trovato e accessibile',
          details: `Status: ${swResponse.status}, Tipo: ${swResponse.headers.get('content-type')}`
        });
      } else {
        results.push({
          name: 'File Service Worker',
          status: 'error',
          message: 'File sw.js non trovato',
          details: `HTTP ${swResponse.status}: ${swResponse.statusText}`,
          action: 'Verifica che il file sw.js sia presente nella root del progetto'
        });
      }
    } catch (error) {
      results.push({
        name: 'File Service Worker',
        status: 'error',
        message: 'Errore nel caricare sw.js',
        details: error instanceof Error ? error.message : 'Errore sconosciuto',
        action: 'Controlla la console del browser per dettagli'
      });
    }

    // 5. Check Manifest file
    try {
      const manifestResponse = await fetch('/manifest.json');
      if (manifestResponse.ok) {
        const manifest = await manifestResponse.json();
        results.push({
          name: 'File Manifest',
          status: 'success',
          message: 'Manifest PWA trovato e valido',
          details: `Nome: ${manifest.name}, Icone: ${manifest.icons?.length || 0}`
        });
      } else {
        results.push({
          name: 'File Manifest',
          status: 'error',
          message: 'Manifest.json non trovato',
          details: `HTTP ${manifestResponse.status}`,
          action: 'Verifica che manifest.json sia presente nella root'
        });
      }
    } catch (error) {
      results.push({
        name: 'File Manifest',
        status: 'error',
        message: 'Errore nel caricare manifest.json',
        details: error instanceof Error ? error.message : 'Errore sconosciuto'
      });
    }

    // 6. Check actual Service Worker registration
    if ('serviceWorker' in navigator) {
      try {
        const registration = await navigator.serviceWorker.getRegistration('/');
        if (registration) {
          results.push({
            name: 'Service Worker Registrato',
            status: 'success',
            message: 'Service Worker registrato correttamente',
            details: `Scope: ${registration.scope}, State: ${registration.active?.state || 'unknown'}`
          });
        } else {
          results.push({
            name: 'Service Worker Registrato',
            status: 'warning',
            message: 'Service Worker non ancora registrato',
            details: 'Il Service Worker non è stato registrato. Potrebbe essere in fase di installazione.',
            action: 'Ricarica la pagina o attendi qualche secondo'
          });
        }
      } catch (error) {
        results.push({
          name: 'Service Worker Registrato',
          status: 'error',
          message: 'Errore nella verifica registrazione',
          details: error instanceof Error ? error.message : 'Errore sconosciuto'
        });
      }
    }

    // 7. Check Cache API
    if ('caches' in window) {
      try {
        const cacheNames = await caches.keys();
        results.push({
          name: 'Cache API',
          status: 'success',
          message: 'Cache API disponibile',
          details: `Cache trovate: ${cacheNames.length} (${cacheNames.join(', ')})`
        });
      } catch (error) {
        results.push({
          name: 'Cache API',
          status: 'warning',
          message: 'Cache API limitata',
          details: 'Cache API disponibile ma con limitazioni'
        });
      }
    } else {
      results.push({
        name: 'Cache API',
        status: 'error',
        message: 'Cache API non supportata',
        details: 'Il browser non supporta la Cache API'
      });
    }

    // 8. Check Network Status
    results.push({
      name: 'Stato Rete',
      status: navigator.onLine ? 'success' : 'warning',
      message: navigator.onLine ? 'Online' : 'Offline',
      details: `Navigator.onLine: ${navigator.onLine}`
    });

    // 9. Check Installation Capability
    let installPromptAvailable = false;
    try {
      // Listen for beforeinstallprompt temporarily
      const handleInstallPrompt = () => { installPromptAvailable = true; };
      window.addEventListener('beforeinstallprompt', handleInstallPrompt);
      
      setTimeout(() => {
        window.removeEventListener('beforeinstallprompt', handleInstallPrompt);
        
        if (installPromptAvailable) {
          results.push({
            name: 'Installabilità PWA',
            status: 'success',
            message: 'App installabile',
            details: 'L\'app può essere installata come PWA'
          });
        } else {
          const isInstalled = window.matchMedia('(display-mode: standalone)').matches;
          if (isInstalled) {
            results.push({
              name: 'Installabilità PWA',
              status: 'info',
              message: 'App già installata',
              details: 'L\'app è già installata come PWA'
            });
          } else {
            results.push({
              name: 'Installabilità PWA',
              status: 'warning',
              message: 'Prompt installazione non disponibile',
              details: 'Il browser potrebbe non supportare l\'installazione automatica'
            });
          }
        }
        
        setDiagnostics([...results]);
        setIsRunning(false);
      }, 1000);
    } catch (error) {
      results.push({
        name: 'Installabilità PWA',
        status: 'warning',
        message: 'Impossibile verificare installabilità',
        details: 'Test di installazione non riuscito'
      });
    }

    if (!installPromptAvailable) {
      setDiagnostics(results);
      setIsRunning(false);
    }
  };

  useEffect(() => {
    runDiagnostics();
  }, []);

  const getStatusIcon = (status: DiagnosticResult['status']) => {
    switch (status) {
      case 'success': return <CheckCircle className="w-4 h-4 text-green-600" />;
      case 'warning': return <AlertTriangle className="w-4 h-4 text-yellow-600" />;
      case 'error': return <XCircle className="w-4 h-4 text-red-600" />;
      case 'info': return <Info className="w-4 h-4 text-blue-600" />;
    }
  };

  const getStatusColor = (status: DiagnosticResult['status']) => {
    switch (status) {
      case 'success': return 'bg-green-50 border-green-200';
      case 'warning': return 'bg-yellow-50 border-yellow-200';
      case 'error': return 'bg-red-50 border-red-200';
      case 'info': return 'bg-blue-50 border-blue-200';
    }
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    toast.success('Copiato negli appunti!');
  };

  const errorCount = diagnostics.filter(d => d.status === 'error').length;
  const warningCount = diagnostics.filter(d => d.status === 'warning').length;
  const successCount = diagnostics.filter(d => d.status === 'success').length;

  return (
    <div className="space-y-6">
      {/* Header */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Shield className="w-6 h-6 text-blue-600" />
              <div>
                <CardTitle>Diagnostica Service Worker</CardTitle>
                <p className="text-sm text-gray-600 mt-1">
                  Verifica della configurazione PWA e Service Worker
                </p>
              </div>
            </div>
            <Button 
              onClick={runDiagnostics} 
              disabled={isRunning}
              variant="outline"
              size="sm"
            >
              {isRunning ? (
                <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
              ) : (
                <RefreshCw className="w-4 h-4 mr-2" />
              )}
              Riesegui Test
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2">
              <CheckCircle className="w-4 h-4 text-green-600" />
              <span className="text-sm">{successCount} Successi</span>
            </div>
            <div className="flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-yellow-600" />
              <span className="text-sm">{warningCount} Avvisi</span>
            </div>
            <div className="flex items-center gap-2">
              <XCircle className="w-4 h-4 text-red-600" />
              <span className="text-sm">{errorCount} Errori</span>
            </div>
          </div>

          {errorCount === 0 && warningCount === 0 && (
            <div className="mt-4 p-3 bg-green-50 border border-green-200 rounded-lg">
              <div className="flex items-center gap-2">
                <CheckCircle className="w-4 h-4 text-green-600" />
                <span className="font-medium text-green-800">
                  🎉 Service Worker configurato correttamente!
                </span>
              </div>
              <p className="text-sm text-green-700 mt-1">
                Tutti i test sono passati. L'app PWA dovrebbe funzionare perfettamente.
              </p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Diagnostics Results */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle>Risultati Test</CardTitle>
            <Button 
              onClick={() => setShowDetails(!showDetails)}
              variant="ghost"
              size="sm"
            >
              {showDetails ? 'Nascondi' : 'Mostra'} Dettagli
            </Button>
          </div>
        </CardHeader>
        <CardContent className="space-y-3">
          {diagnostics.map((diagnostic, index) => (
            <div key={index} className={`p-3 rounded-lg border ${getStatusColor(diagnostic.status)}`}>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  {getStatusIcon(diagnostic.status)}
                  <div>
                    <h4 className="font-medium">{diagnostic.name}</h4>
                    <p className="text-sm opacity-80">{diagnostic.message}</p>
                  </div>
                </div>
                {diagnostic.status === 'error' && (
                  <Badge variant="destructive">Critico</Badge>
                )}
                {diagnostic.status === 'warning' && (
                  <Badge variant="secondary">Attenzione</Badge>
                )}
              </div>

              {showDetails && diagnostic.details && (
                <div className="mt-3 pt-3 border-t border-current/20">
                  <p className="text-xs font-mono bg-black/5 p-2 rounded">
                    {diagnostic.details}
                  </p>
                </div>
              )}

              {diagnostic.action && (
                <div className="mt-3 pt-3 border-t border-current/20">
                  <div className="flex items-center gap-2">
                    <Info className="w-3 h-3" />
                    <p className="text-xs font-medium">Azione consigliata:</p>
                  </div>
                  <p className="text-xs mt-1">{diagnostic.action}</p>
                </div>
              )}
            </div>
          ))}

          {isRunning && (
            <div className="text-center py-8">
              <RefreshCw className="w-6 h-6 animate-spin mx-auto mb-2 text-gray-400" />
              <p className="text-sm text-gray-600">Esecuzione test in corso...</p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Quick Actions */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Terminal className="w-5 h-5" />
            Azioni Rapide
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <Button 
              onClick={() => {
                window.open('/sw.js', '_blank');
              }}
              variant="outline"
              className="justify-start"
            >
              <ExternalLink className="w-4 h-4 mr-2" />
              Visualizza sw.js
            </Button>

            <Button 
              onClick={() => {
                window.open('/manifest.json', '_blank');
              }}
              variant="outline"
              className="justify-start"
            >
              <Globe className="w-4 h-4 mr-2" />
              Visualizza Manifest
            </Button>

            <Button 
              onClick={() => {
                copyToClipboard(window.location.href);
              }}
              variant="outline"
              className="justify-start"
            >
              <Copy className="w-4 h-4 mr-2" />
              Copia URL App
            </Button>

            <Button 
              onClick={() => {
                if ('serviceWorker' in navigator) {
                  navigator.serviceWorker.register('/sw.js', { scope: '/' })
                    .then(() => toast.success('Service Worker registrato!'))
                    .catch(() => toast.error('Errore registrazione'));
                }
              }}
              variant="outline"
              className="justify-start"
            >
              <Shield className="w-4 h-4 mr-2" />
              Forza Registrazione
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Instructions */}
      <Card>
        <CardHeader>
          <CardTitle>Istruzioni per il Setup</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-3">
            <h4 className="font-medium">Per Environment Locale:</h4>
            <div className="bg-gray-50 p-3 rounded-lg text-sm space-y-2">
              <p>1. Assicurati che i file <code>sw.js</code> e <code>manifest.json</code> siano nella root</p>
              <p>2. Serve l'app su <code>localhost</code> o <code>https://</code></p>
              <p>3. Apri Chrome DevTools → Application → Service Workers per debug</p>
              <p>4. Controlla la console per eventuali errori</p>
            </div>
          </div>

          <Separator />

          <div className="space-y-3">
            <h4 className="font-medium">Per Produzione:</h4>
            <div className="bg-gray-50 p-3 rounded-lg text-sm space-y-2">
              <p>1. Deploy su un server HTTPS</p>
              <p>2. Verifica che tutti i file statici siano accessibili</p>
              <p>3. Testa l'installazione PWA</p>
              <p>4. Verifica il funzionamento offline</p>
            </div>
          </div>

          <Separator />

          <div className="space-y-3">
            <h4 className="font-medium">Debug Common Issues:</h4>
            <div className="bg-red-50 p-3 rounded-lg text-sm space-y-2">
              <p>• <strong>SW non si registra:</strong> Controlla HTTPS/localhost</p>
              <p>• <strong>Cache non funziona:</strong> Verifica la strategia di caching</p>
              <p>• <strong>Install prompt non appare:</strong> Controlla i criteri PWA</p>
              <p>• <strong>Offline non funziona:</strong> Verifica le route cachate</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {onClose && (
        <div className="flex justify-end">
          <Button onClick={onClose} variant="outline">
            Chiudi Diagnostica
          </Button>
        </div>
      )}
    </div>
  );
}