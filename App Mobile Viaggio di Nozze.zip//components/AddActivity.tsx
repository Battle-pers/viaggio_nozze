import React, { useState } from 'react';
import { Plus, Save, X, Camera, MapPin, Utensils, Car, Hotel, Compass, Binoculars, Ship, ExternalLink } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Textarea } from './ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from './ui/dialog';
import { Label } from './ui/label';
import { Activity } from '../data/itinerary';

interface AddActivityProps {
  isOpen: boolean;
  onOpenChange: (open: boolean) => void;
  onAdd: (activity: Omit<Activity, 'id'>) => void;
  suggestedTime?: string;
}

export default function AddActivity({ isOpen, onOpenChange, onAdd, suggestedTime }: AddActivityProps) {
  const [newActivity, setNewActivity] = useState<Omit<Activity, 'id'>>({
    time: suggestedTime || '12:00',
    title: '',
    description: '',
    location: '',
    type: 'activity',
    notes: '',
    mapLink: ''
  });

  const handleAdd = () => {
    if (newActivity.title.trim()) {
      onAdd({
        ...newActivity,
        title: newActivity.title.trim(),
        description: newActivity.description?.trim() || undefined,
        location: newActivity.location?.trim() || undefined,
        notes: newActivity.notes?.trim() || undefined,
        mapLink: newActivity.mapLink?.trim() || undefined
      });
      onOpenChange(false);
      // Reset form
      setNewActivity({
        time: suggestedTime || '12:00',
        title: '',
        description: '',
        location: '',
        type: 'activity',
        notes: '',
        mapLink: ''
      });
    }
  };

  const activityTypes = [
    { value: 'activity', label: 'Attività', icon: Camera },
    { value: 'exploration', label: 'Esplorazione', icon: Compass },
    { value: 'meal', label: 'Pasto', icon: Utensils },
    { value: 'transport', label: 'Trasporto', icon: Car },
    { value: 'hotel', label: 'Hotel', icon: Hotel },
    { value: 'safari', label: 'Safari', icon: Binoculars },
    { value: 'ferry', label: 'Traghetto', icon: Ship }
  ];

  const getTypeIcon = (type: string) => {
    const typeObj = activityTypes.find(t => t.value === type);
    return typeObj ? typeObj.icon : Camera;
  };

  const TypeIcon = getTypeIcon(newActivity.type);

  // Function to validate URL
  const isValidUrl = (string: string) => {
    try {
      new URL(string);
      return true;
    } catch (_) {
      return false;
    }
  };

  const handleOpenMap = () => {
    if (newActivity.mapLink && isValidUrl(newActivity.mapLink)) {
      window.open(newActivity.mapLink, '_blank');
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-xl">
            <Plus className="w-5 h-5" />
            Aggiungi Nuova Attività
          </DialogTitle>
          <DialogDescription>
            Crea una nuova attività personalizzata per il tuo itinerario. Compila tutti i campi necessari.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6 py-4">
          {/* Activity Type & Preview */}
          <div className="space-y-3">
            <Label className="text-base font-medium">Tipo Attività</Label>
            <Select 
              value={newActivity.type} 
              onValueChange={(value) => setNewActivity(prev => ({ ...prev, type: value as Activity['type'] }))}
            >
              <SelectTrigger className="w-full h-12">
                <SelectValue>
                  <div className="flex items-center gap-2">
                    <TypeIcon className="w-4 h-4" />
                    {activityTypes.find(t => t.value === newActivity.type)?.label}
                  </div>
                </SelectValue>
              </SelectTrigger>
              <SelectContent>
                {activityTypes.map((type) => {
                  const Icon = type.icon;
                  return (
                    <SelectItem key={type.value} value={type.value}>
                      <div className="flex items-center gap-2">
                        <Icon className="w-4 h-4" />
                        {type.label}
                      </div>
                    </SelectItem>
                  );
                })}
              </SelectContent>
            </Select>
          </div>

          {/* Time and Duration */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label className="text-base font-medium">Orario</Label>
              <Input
                type="time"
                value={newActivity.time}
                onChange={(e) => setNewActivity(prev => ({ ...prev, time: e.target.value }))}
                className="h-12"
              />
            </div>
            <div className="space-y-2">
              <Label className="text-base font-medium">Durata</Label>
              <Input
                placeholder="es. 2h 30min"
                value={newActivity.duration || ''}
                onChange={(e) => setNewActivity(prev => ({ ...prev, duration: e.target.value }))}
                className="h-12"
              />
            </div>
          </div>

          {/* Title - Required */}
          <div className="space-y-2">
            <Label className="text-base font-medium">
              Titolo <span className="text-red-500">*</span>
            </Label>
            <Input
              value={newActivity.title}
              onChange={(e) => setNewActivity(prev => ({ ...prev, title: e.target.value }))}
              className="h-12"
              placeholder="Nome dell'attività"
              required
            />
          </div>

          {/* Description */}
          <div className="space-y-2">
            <Label className="text-base font-medium">Descrizione</Label>
            <Textarea
              value={newActivity.description || ''}
              onChange={(e) => setNewActivity(prev => ({ ...prev, description: e.target.value }))}
              className="min-h-[100px] resize-none"
              placeholder="Descrizione dell'attività..."
            />
          </div>

          {/* Location */}
          <div className="space-y-2">
            <Label className="text-base font-medium flex items-center gap-2">
              <MapPin className="w-4 h-4" />
              Località
            </Label>
            <Input
              value={newActivity.location || ''}
              onChange={(e) => setNewActivity(prev => ({ ...prev, location: e.target.value }))}
              className="h-12"
              placeholder="Dove si svolge l'attività"
            />
          </div>

          {/* Maps Link */}
          <div className="space-y-3">
            <Label className="text-base font-medium flex items-center gap-2">
              <MapPin className="w-4 h-4" />
              Link Maps
            </Label>
            <div className="flex gap-2">
              <Input
                value={newActivity.mapLink || ''}
                onChange={(e) => setNewActivity(prev => ({ ...prev, mapLink: e.target.value }))}
                className="h-12 flex-1"
                placeholder="https://maps.app.goo.gl/..."
                type="url"
              />
              {newActivity.mapLink && isValidUrl(newActivity.mapLink) && (
                <Button
                  type="button"
                  variant="outline"
                  onClick={handleOpenMap}
                  className="h-12 px-4"
                  title="Apri in Google Maps"
                >
                  <ExternalLink className="w-4 h-4" />
                </Button>
              )}
            </div>
            <p className="text-sm text-gray-500">
              Aggiungi un link di Google Maps per facilitare la navigazione verso questa località
            </p>
          </div>

          {/* Notes */}
          <div className="space-y-2">
            <Label className="text-base font-medium">Note</Label>
            <Textarea
              value={newActivity.notes || ''}
              onChange={(e) => setNewActivity(prev => ({ ...prev, notes: e.target.value }))}
              className="min-h-[80px] resize-none"
              placeholder="Note aggiuntive..."
            />
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex gap-3 pt-4 border-t">
          <Button 
            onClick={handleAdd} 
            className="flex-1 h-12" 
            disabled={!newActivity.title.trim()}
          >
            <Save className="w-4 h-4 mr-2" />
            Aggiungi Attività
          </Button>
          <Button 
            variant="outline" 
            onClick={() => onOpenChange(false)} 
            className="h-12 px-6"
          >
            <X className="w-4 h-4" />
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}