import React from 'react';
import { Download, Image as ImageIcon } from 'lucide-react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { generateAppIcons } from './AppIcon';

export default function IconGenerator() {
  const handleGenerateIcons = () => {
    generateAppIcons();
  };

  return (
    <Card className="max-w-md mx-auto">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <ImageIcon className="w-5 h-5" />
          Genera Icone App
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <p className="text-sm text-gray-600">
          Clicca il pulsante qui sotto per generare e scaricare le icone dell'app nelle dimensioni corrette (192x192 e 512x512).
        </p>
        
        <Button 
          onClick={handleGenerateIcons}
          className="w-full gap-2"
        >
          <Download className="w-4 h-4" />
          Scarica Icone App
        </Button>
        
        <div className="text-xs text-gray-500 space-y-1">
          <p><strong>Istruzioni:</strong></p>
          <p>1. Clicca il pulsante per scaricare le icone</p>
          <p>2. Salva i file come "app-icon-192.png" e "app-icon-512.png"</p>
          <p>3. Carica i file nella root del progetto</p>
        </div>
      </CardContent>
    </Card>
  );
}