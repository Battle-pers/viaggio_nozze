import React, { useState } from 'react';
import { Heart, Lock, Calendar } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import AppIcon from './AppIcon';

interface LoginProps {
  onLogin: () => void;
}

export default function Login({ onLogin }: LoginProps) {
  const [password, setPassword] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setError('');

    // Simulate loading for better UX
    await new Promise(resolve => setTimeout(resolve, 800));

    // Simple password check - in a real app, this would be more secure
    if (password.toLowerCase() === 'alice' || password.toLowerCase() === 'alessandro' || password === '27.06.25') {
      onLogin();
    } else {
      setError('Password non corretta. Prova con "Alice", "Alessandro" o "27.06.25"');
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-pink-50 via-white to-blue-50 flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        {/* Logo Section */}
        <div className="text-center mb-8">
          <div className="flex justify-center mb-4">
            <AppIcon size={80} />
          </div>
          <h1 className="text-3xl font-bold text-gray-800 mb-2">27.06.25</h1>
          <p className="text-gray-600">Alice &amp; Alessandro</p>
          <p className="text-sm text-gray-500 mt-1">Il nostro matrimonio e viaggio di nozze</p>
        </div>

        {/* Login Card */}
        <Card className="shadow-xl border-0 bg-white/95 backdrop-blur-sm">
          <CardHeader className="text-center pb-4">
            <CardTitle className="flex items-center justify-center gap-2 text-lg">
              <Lock className="w-5 h-5 text-pink-600" />
              Accesso Privato
            </CardTitle>
            <p className="text-sm text-gray-600 mt-2">
              Inserisci la password per accedere ai nostri ricordi
            </p>
          </CardHeader>
          
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <Input
                  type="password"
                  placeholder="Password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full text-center text-lg tracking-wider"
                  disabled={isLoading}
                  autoFocus
                />
                {error && (
                  <p className="text-red-500 text-sm mt-2 text-center">{error}</p>
                )}
              </div>
              
              <Button 
                type="submit" 
                className="w-full bg-gradient-to-r from-pink-500 to-rose-500 hover:from-pink-600 hover:to-rose-600 text-white shadow-lg"
                disabled={isLoading || !password}
              >
                {isLoading ? (
                  <div className="flex items-center gap-2">
                    <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                    Accesso in corso...
                  </div>
                ) : (
                  <div className="flex items-center gap-2">
                    <Heart className="w-4 h-4" />
                    Entra
                  </div>
                )}
              </Button>
            </form>
            
            <div className="mt-6 text-center">
              <p className="text-xs text-gray-500">
                Suggerimento: prova con uno dei nostri nomi o la data del matrimonio
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Wedding Date Highlight */}
        <div className="mt-6 text-center">
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-white/80 backdrop-blur-sm rounded-full border border-pink-200 shadow-sm">
            <Calendar className="w-4 h-4 text-pink-600" />
            <span className="text-sm font-medium text-gray-700">27 Giugno 2025</span>
            <Heart className="w-4 h-4 text-pink-600 fill-current" />
          </div>
        </div>
      </div>
    </div>
  );
}