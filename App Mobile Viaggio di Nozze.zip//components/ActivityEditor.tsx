import React, { useState } from 'react';
import { Edit, Save, X, MapPin, Clock, Trash2, AlertTriangle, Camera, Compass, Utensils, Car, Hotel, Plane, Binoculars, Ship, ExternalLink } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Textarea } from './ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from './ui/dialog';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from './ui/alert-dialog';
import { Label } from './ui/label';
import { Badge } from './ui/badge';
import { Activity } from '../data/itinerary';

interface ActivityEditorProps {
  activity: Activity;
  onSave: (activity: Activity) => void;
  onDelete?: () => void;
  isOpen: boolean;
  onOpenChange: (open: boolean) => void;
}

export default function ActivityEditor({ activity, onSave, onDelete, isOpen, onOpenChange }: ActivityEditorProps) {
  const [editedActivity, setEditedActivity] = useState<Activity>({ ...activity });
  const [userNotes, setUserNotes] = useState(activity.userNotes || '');

  const handleSave = () => {
    const updatedActivity = {
      ...editedActivity,
      userNotes: userNotes.trim() || undefined
    };
    onSave(updatedActivity);
    onOpenChange(false);
  };

  const activityTypes = [
    { value: 'flight', label: 'Volo', icon: Plane },
    { value: 'hotel', label: 'Hotel', icon: Hotel },
    { value: 'checkin', label: 'Check-in', icon: Hotel },
    { value: 'checkout', label: 'Check-out', icon: Hotel },
    { value: 'transport', label: 'Trasporto', icon: Car },
    { value: 'activity', label: 'Attività', icon: Camera },
    { value: 'exploration', label: 'Esplorazione', icon: Compass },
    { value: 'meal', label: 'Pasto', icon: Utensils },
    { value: 'safari', label: 'Safari', icon: Binoculars },
    { value: 'ferry', label: 'Traghetto', icon: Ship }
  ];

  const getTypeIcon = (type: string) => {
    const typeObj = activityTypes.find(t => t.value === type);
    return typeObj ? typeObj.icon : Camera;
  };

  const TypeIcon = getTypeIcon(editedActivity.type);

  const isUserCreated = (activity as any).isUserCreated;

  // Function to validate URL
  const isValidUrl = (string: string) => {
    try {
      new URL(string);
      return true;
    } catch (_) {
      return false;
    }
  };

  const handleOpenMap = () => {
    if (editedActivity.mapLink && isValidUrl(editedActivity.mapLink)) {
      window.open(editedActivity.mapLink, '_blank');
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center justify-between">
            <div className="flex items-center gap-2 text-xl">
              <Edit className="w-5 h-5" />
              Modifica Attività
            </div>
            <div className="flex items-center gap-2">
              {activity.isPlaceholder && (
                <Badge variant="outline" className="text-indigo-600 border-indigo-200">
                  Da esplorare
                </Badge>
              )}
              {isUserCreated && (
                <Badge variant="outline" className="text-purple-600 border-purple-200">
                  Personalizzato
                </Badge>
              )}
            </div>
          </DialogTitle>
          <DialogDescription>
            Modifica i dettagli dell&apos;attività, aggiungi note personali e aggiorna le informazioni di viaggio.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6 py-4">
          {/* Activity Type & Preview */}
          <div className="space-y-3">
            <Label className="text-base font-medium">Tipo Attività</Label>
            <Select 
              value={editedActivity.type} 
              onValueChange={(value) => setEditedActivity(prev => ({ ...prev, type: value as Activity['type'] }))}
            >
              <SelectTrigger className="w-full h-12">
                <SelectValue>
                  <div className="flex items-center gap-2">
                    <TypeIcon className="w-4 h-4" />
                    {activityTypes.find(t => t.value === editedActivity.type)?.label}
                  </div>
                </SelectValue>
              </SelectTrigger>
              <SelectContent>
                {activityTypes.map((type) => {
                  const Icon = type.icon;
                  return (
                    <SelectItem key={type.value} value={type.value}>
                      <div className="flex items-center gap-2">
                        <Icon className="w-4 h-4" />
                        {type.label}
                      </div>
                    </SelectItem>
                  );
                })}
              </SelectContent>
            </Select>
          </div>

          {/* Time and Duration */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label className="text-base font-medium flex items-center gap-2">
                <Clock className="w-4 h-4" />
                Orario
              </Label>
              <Input
                type="time"
                value={editedActivity.time}
                onChange={(e) => setEditedActivity(prev => ({ ...prev, time: e.target.value }))}
                className="h-12"
              />
            </div>
            <div className="space-y-2">
              <Label className="text-base font-medium">Durata</Label>
              <Input
                placeholder="es. 2h 30min"
                value={editedActivity.duration || ''}
                onChange={(e) => setEditedActivity(prev => ({ ...prev, duration: e.target.value }))}
                className="h-12"
              />
            </div>
          </div>

          {/* Title */}
          <div className="space-y-2">
            <Label className="text-base font-medium">Titolo</Label>
            <Input
              value={editedActivity.title}
              onChange={(e) => setEditedActivity(prev => ({ ...prev, title: e.target.value }))}
              className="h-12"
              placeholder="Nome dell'attività"
            />
          </div>

          {/* Description */}
          <div className="space-y-2">
            <Label className="text-base font-medium">Descrizione</Label>
            <Textarea
              value={editedActivity.description || ''}
              onChange={(e) => setEditedActivity(prev => ({ ...prev, description: e.target.value }))}
              className="min-h-[100px] resize-none"
              placeholder="Descrizione dell'attività..."
            />
          </div>

          {/* Location */}
          <div className="space-y-2">
            <Label className="text-base font-medium flex items-center gap-2">
              <MapPin className="w-4 h-4" />
              Località
            </Label>
            <Input
              value={editedActivity.location || ''}
              onChange={(e) => setEditedActivity(prev => ({ ...prev, location: e.target.value }))}
              className="h-12"
              placeholder="Dove si svolge l'attività"
            />
          </div>

          {/* Maps Link */}
          <div className="space-y-3">
            <Label className="text-base font-medium flex items-center gap-2">
              <MapPin className="w-4 h-4" />
              Link Maps
            </Label>
            <div className="flex gap-2">
              <Input
                value={editedActivity.mapLink || ''}
                onChange={(e) => setEditedActivity(prev => ({ ...prev, mapLink: e.target.value }))}
                className="h-12 flex-1"
                placeholder="https://maps.app.goo.gl/..."
                type="url"
              />
              {editedActivity.mapLink && isValidUrl(editedActivity.mapLink) && (
                <Button
                  type="button"
                  variant="outline"
                  onClick={handleOpenMap}
                  className="h-12 px-4"
                  title="Apri in Google Maps"
                >
                  <ExternalLink className="w-4 h-4" />
                </Button>
              )}
            </div>
            <p className="text-sm text-gray-500">
              Aggiungi un link di Google Maps per facilitare la navigazione verso questa località
            </p>
          </div>

          {/* User Notes */}
          <div className="space-y-2">
            <Label className="text-base font-medium flex items-center gap-2">
              <Edit className="w-4 h-4" />
              Note Personali
            </Label>
            <Textarea
              value={userNotes}
              onChange={(e) => setUserNotes(e.target.value)}
              className="min-h-[120px] bg-yellow-50 border-yellow-200 resize-none"
              placeholder="Aggiungi le tue note personali per questa attività..."
            />
            <p className="text-sm text-gray-500">
              Le note personali verranno salvate localmente e saranno visibili solo a te
            </p>
          </div>

          {/* Travel Time */}
          {editedActivity.travelTime && (
            <div className="space-y-3">
              <Label className="text-base font-medium">Informazioni Spostamento</Label>
              <div className="bg-blue-50 p-4 rounded-lg space-y-3">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div className="space-y-2">
                    <Label className="text-sm">Partenza</Label>
                    <Input
                      placeholder="Punto di partenza"
                      value={editedActivity.travelTime.from}
                      onChange={(e) => setEditedActivity(prev => ({
                        ...prev,
                        travelTime: prev.travelTime ? { ...prev.travelTime, from: e.target.value } : undefined
                      }))}
                      className="h-10"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label className="text-sm">Destinazione</Label>
                    <Input
                      placeholder="Punto di arrivo"
                      value={editedActivity.travelTime.to}
                      onChange={(e) => setEditedActivity(prev => ({
                        ...prev,
                        travelTime: prev.travelTime ? { ...prev.travelTime, to: e.target.value } : undefined
                      }))}
                      className="h-10"
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label className="text-sm">Durata viaggio</Label>
                  <Input
                    placeholder="es. 1h 30min"
                    value={editedActivity.travelTime.duration}
                    onChange={(e) => setEditedActivity(prev => ({
                      ...prev,
                      travelTime: prev.travelTime ? { ...prev.travelTime, duration: e.target.value } : undefined
                    }))}
                    className="h-10"
                  />
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Action Buttons */}
        <div className="flex gap-3 pt-4 border-t">
          <Button onClick={handleSave} className="flex-1 h-12">
            <Save className="w-4 h-4 mr-2" />
            Salva Modifiche
          </Button>
          
          {onDelete && (
            <AlertDialog>
              <AlertDialogTrigger asChild>
                <Button variant="destructive" className="h-12 px-6">
                  <Trash2 className="w-4 h-4" />
                </Button>
              </AlertDialogTrigger>
              <AlertDialogContent>
                <AlertDialogHeader>
                  <AlertDialogTitle className="flex items-center gap-2">
                    <AlertTriangle className="w-5 h-5 text-red-500" />
                    {isUserCreated ? 'Elimina attività' : 'Nascondi attività'}
                  </AlertDialogTitle>
                  <AlertDialogDescription>
                    {isUserCreated 
                      ? 'Sei sicuro di voler eliminare definitivamente questa attività? Questa azione non può essere annullata.'
                      : 'Sei sicuro di voler nascondere questa attività dalla timeline? Potrai sempre mostrarla nuovamente in seguito.'
                    }
                  </AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                  <AlertDialogCancel>Annulla</AlertDialogCancel>
                  <AlertDialogAction 
                    onClick={() => {
                      onDelete();
                      onOpenChange(false);
                    }}
                    className="bg-red-600 hover:bg-red-700"
                  >
                    {isUserCreated ? 'Elimina' : 'Nascondi'}
                  </AlertDialogAction>
                </AlertDialogFooter>
              </AlertDialogContent>
            </AlertDialog>
          )}
          
          <Button 
            variant="outline" 
            onClick={() => onOpenChange(false)} 
            className="h-12 px-6"
          >
            <X className="w-4 h-4" />
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}