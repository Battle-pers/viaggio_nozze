import React, { useRef, useEffect } from 'react';
import { ChevronLeft, ChevronRight, MapPin } from 'lucide-react';
import { Button } from './ui/button';
import { DayPlan } from '../data/itinerary';

interface HorizontalCalendarProps {
  itinerary: DayPlan[];
  selectedDate: string | null;
  onDateSelect: (date: string) => void;
  currentDate: string;
  onPreviousDay?: () => void;
  onNextDay?: () => void;
}

export default function HorizontalCalendar({ 
  itinerary, 
  selectedDate, 
  onDateSelect, 
  currentDate,
  onPreviousDay,
  onNextDay
}: HorizontalCalendarProps) {
  const scrollRef = useRef<HTMLDivElement>(null);

  const formatDate = (dateStr: string) => {
    const date = new Date(dateStr);
    const dayNames = ['DOM', 'LUN', 'MAR', 'MER', 'GIO', 'VEN', 'SAB'];
    const monthNames = ['gen', 'feb', 'mar', 'apr', 'mag', 'giu', 'lug', 'ago', 'set', 'ott', 'nov', 'dic'];
    
    return {
      dayName: dayNames[date.getDay()],
      day: date.getDate().toString(),
      month: monthNames[date.getMonth()]
    };
  };

  const getLocationShort = (location: string) => {
    // Extract first part before comma and shorten if needed
    const firstPart = location.split(',')[0];
    
    // Handle specific cases for better display
    if (firstPart.includes('Cape Town')) return 'Cape Town';
    if (firstPart.includes('Kruger')) return 'Kruger';
    if (firstPart.includes('Seychelles')) return 'Seychelles';
    if (firstPart.includes('Milano')) return 'Milano';
    if (firstPart.includes('Mahe')) return 'Mahé';
    if (firstPart.includes('Praslin')) return 'Praslin';
    if (firstPart.includes('La Digue')) return 'La Digue';
    if (firstPart.includes('Graskop')) return 'Graskop';
    if (firstPart.includes('Johannesburg')) return 'Joburg';
    if (firstPart.includes('Malpensa')) return 'Malpensa';
    
    // If short enough, return as is
    if (firstPart.length <= 10) return firstPart;
    
    // Fallback: truncate to 10 chars
    return firstPart.substring(0, 10);
  };

  const scrollToSelectedDate = () => {
    if (!scrollRef.current || !selectedDate) return;
    
    const selectedElement = scrollRef.current.querySelector(`[data-date="${selectedDate}"]`);
    if (selectedElement) {
      const container = scrollRef.current;
      const elementLeft = (selectedElement as HTMLElement).offsetLeft;
      const elementWidth = (selectedElement as HTMLElement).offsetWidth;
      const containerWidth = container.offsetWidth;
      
      const scrollLeft = elementLeft - (containerWidth / 2) + (elementWidth / 2);
      container.scrollTo({ left: scrollLeft, behavior: 'smooth' });
    }
  };

  const scrollLeft = () => {
    if (scrollRef.current) {
      scrollRef.current.scrollBy({ left: -200, behavior: 'smooth' });
    }
  };

  const scrollRight = () => {
    if (scrollRef.current) {
      scrollRef.current.scrollBy({ left: 200, behavior: 'smooth' });
    }
  };

  // Enhanced navigation functions
  const handlePreviousDay = () => {
    if (onPreviousDay) {
      onPreviousDay();
    } else {
      scrollLeft();
    }
  };

  const handleNextDay = () => {
    if (onNextDay) {
      onNextDay();
    } else {
      scrollRight();
    }
  };

  // Auto-scroll to selected date on mount and when selection changes
  useEffect(() => {
    const timeoutId = setTimeout(scrollToSelectedDate, 100);
    return () => clearTimeout(timeoutId);
  }, [selectedDate]);

  const isToday = (date: string) => date === currentDate;
  const isPast = (date: string) => date < currentDate;
  const isFuture = (date: string) => date > currentDate;

  // Get navigation button states
  const currentIndex = selectedDate ? itinerary.findIndex(day => day.date === selectedDate) : -1;
  const canGoPrevious = currentIndex > 0;
  const canGoNext = currentIndex < itinerary.length - 1;

  return (
    <div className="bg-white border-b border-gray-200 shadow-sm">
      <div className="max-w-6xl mx-auto relative">
        {/* Left Navigation Button */}
        <Button
          variant="ghost"
          size="sm"
          className={`absolute left-2 top-1/2 -translate-y-1/2 z-10 bg-white/90 backdrop-blur-sm border border-gray-200 shadow-sm hover:bg-white h-8 w-8 p-0 transition-all ${
            !canGoPrevious ? 'opacity-50 cursor-not-allowed' : 'hover:scale-105'
          }`}
          onClick={handlePreviousDay}
          disabled={!canGoPrevious}
          title="Giorno precedente"
        >
          <ChevronLeft className="w-4 h-4" />
        </Button>

        {/* Right Navigation Button */}
        <Button
          variant="ghost"
          size="sm"
          className={`absolute right-2 top-1/2 -translate-y-1/2 z-10 bg-white/90 backdrop-blur-sm border border-gray-200 shadow-sm hover:bg-white h-8 w-8 p-0 transition-all ${
            !canGoNext ? 'opacity-50 cursor-not-allowed' : 'hover:scale-105'
          }`}
          onClick={handleNextDay}
          disabled={!canGoNext}
          title="Giorno successivo"
        >
          <ChevronRight className="w-4 h-4" />
        </Button>

        {/* Calendar Scroll Container */}
        <div 
          ref={scrollRef}
          className="flex gap-3 overflow-x-auto scrollbar-hide px-12 py-4"
          style={{ scrollbarWidth: 'none', msOverflowStyle: 'none' }}
        >
          {itinerary.map((day) => {
            const formattedDate = formatDate(day.date);
            const isSelected = selectedDate === day.date;
            const isCurrent = isToday(day.date);
            const isHistoric = isPast(day.date);
            
            return (
              <div
                key={day.date}
                data-date={day.date}
                className={`
                  flex-shrink-0 cursor-pointer rounded-xl px-4 py-1 w-[100px] h-[100px] text-center transition-all duration-300 border flex flex-col justify-center relative overflow-hidden
                  ${isSelected 
                    ? 'bg-blue-50/70 text-blue-800 border-blue-200/50 shadow-md scale-[1.02] ring-1 ring-blue-200/30' 
                    : isCurrent
                    ? 'bg-pink-50 text-pink-700 border-pink-200 hover:bg-pink-100 hover:scale-[1.01]'
                    : isHistoric
                    ? 'bg-gray-50/70 text-gray-600 border-gray-200/50 hover:bg-gray-100/80 hover:scale-[1.01]'
                    : 'bg-white text-gray-700 border-gray-200 hover:bg-blue-50/30 hover:border-blue-300/50 hover:scale-[1.01]'
                  }
                `}
                onClick={() => onDateSelect(day.date)}
              >
                {/* Subtle gradient overlay for selected state */}
                {isSelected && (
                  <div className="absolute inset-0 bg-gradient-to-br from-blue-100/30 to-blue-200/20 pointer-events-none"></div>
                )}
                
                {/* Day Name */}
                <div className={`text-sm font-medium uppercase tracking-wide mb-1 relative z-10 ${
                  isSelected ? 'text-blue-700' : isCurrent ? 'text-pink-600' : 'text-gray-500'
                }`}>
                  {formattedDate.dayName}
                </div>
                
                {/* Day Number */}
                <div className={`text-xl font-bold mb-2 relative z-10 ${
                  isSelected ? 'text-blue-900' : isCurrent ? 'text-pink-700' : 'text-gray-800'
                }`}>
                  {formattedDate.day}
                </div>
                
                {/* Month */}
                <div className={`text-sm mb-1 relative z-10 ${
                  isSelected ? 'text-blue-700' : isCurrent ? 'text-pink-600' : 'text-gray-500'
                }`}>
                  {formattedDate.month}
                </div>
                
                {/* Location */}
                <div className={`text-sm font-medium relative z-10 ${
                  isSelected ? 'text-blue-700' : isCurrent ? 'text-pink-600' : 'text-gray-500'
                }`} title={day.location}>
                  {getLocationShort(day.location)}
                </div>

                {/* Current Day Indicator */}
                {isCurrent && !isSelected && (
                  <div className="absolute -bottom-1 left-1/2 -translate-x-1/2 w-2 h-2 bg-pink-500 rounded-full animate-pulse"></div>
                )}

                {/* Selected Day Indicator */}
                {isSelected && (
                  <div className="absolute -bottom-1 left-1/2 -translate-x-1/2 w-3 h-1 bg-blue-600 rounded-full"></div>
                )}
              </div>
            );
          })}
        </div>

        {/* Navigation Hint - Mobile */}
        <div className="sm:hidden text-center py-2">
          <p className="text-xs text-gray-400">Scorri o usa le frecce per navigare</p>
        </div>
      </div>
    </div>
  );
}